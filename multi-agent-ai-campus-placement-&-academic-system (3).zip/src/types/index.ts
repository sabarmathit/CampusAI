export type UserRole = 'student' | 'faculty' | 'recruiter' | 'placement';

export interface ExtracurricularActivity {
  id: string;
  title: string;
  category: 'Technical' | 'Club Membership' | 'Hackathon' | 'Competition' | 'Certification' | 'Workshop' | 'Leadership' | 'Volunteering' | 'Achievement';
  description: string;
  date: string;
}

export interface ResumeProject {
  title: string;
  description: string;
  techStack?: string[];
  role?: string;
  link?: string;
}

export interface ResumeExperience {
  company: string;
  role: string;
  duration: string;
  description?: string;
}

export interface ResumeEducation {
  degree: string;
  institution: string;
  year?: string;
  score?: string;
}

export interface ResumeData {
  fileName: string;
  fileSize: number; // in bytes
  uploadedAt: string;
  fileType: string;
  extractedSkills: string[];
  programmingLanguages?: string[];
  frameworksTools?: string[];
  projects?: ResumeProject[];
  experience?: ResumeExperience[];
  certifications?: string[];
  education?: ResumeEducation[];
  achievements?: string[];
  parsedText?: string;
  rawText?: string;
  targetRole?: string;
  customTargetRole?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  password?: string;
  avatar?: string;
  profileCompleted?: boolean;
  
  // Personal Info (Section A)
  registerNumber?: string;
  rollNo?: string;
  phone?: string;
  dateOfBirth?: string;
  gender?: string;
  address?: string;
  linkedIn?: string;
  github?: string;
  portfolioUrl?: string;
  bio?: string;

  // Academic Info (Section B)
  collegeName?: string;
  department?: string;
  degree?: string;
  currentYear?: number;
  currentSemester?: number;
  graduationYear?: number;
  cgpa?: number;
  backlogStatus?: 'No Backlogs' | 'Active Backlogs' | 'Cleared Backlogs';
  activeBacklogs?: number;

  // Extracurriculars (Section C)
  extracurriculars?: ExtracurricularActivity[];

  // Resume & Skills (Identified from resume, not manual registration)
  skills?: string[];
  resume?: ResumeData;

  // Role-specific professional attributes
  designation?: string;
  specialization?: string;
  companyName?: string;
  companyLogo?: string;
  officeLocation?: string;
}

export interface Subject {
  id: string;
  code: string;
  name: string;
  department: string;
  credits: number;
  facultyId: string;
  facultyName: string;
  schedule?: string;
}

export interface Assignment {
  id: string;
  title: string;
  subjectId: string;
  subject: string;
  department: string;
  description: string;
  assignedClass?: string;
  createdAt: string;
  dueDate: string; // YYYY-MM-DD
  dueTime?: string; // HH:mm
  maxMarks: number;
  facultyId: string;
  facultyName: string;
  attachmentName?: string;
  allowLateSubmission: boolean;
}

export interface Submission {
  id: string;
  assignmentId: string;
  studentId: string;
  studentName: string;
  studentRollNo: string;
  submittedAt: string;
  fileName: string;
  notes?: string;
  marksObtained?: number;
  feedback?: string;
  gradedAt?: string;
  status: 'submitted' | 'late' | 'graded';
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  studentRollNo: string;
  department: string;
  subjectId: string;
  subject: string;
  date: string; // YYYY-MM-DD
  status: 'present' | 'absent';
  facultyId: string;
  facultyName: string;
  remarks?: string;
}

// Academic Marks Models
export interface AssignmentMarkRecord {
  id: string;
  studentId: string;
  assignmentId: string;
  assignmentTitle: string;
  subjectId: string;
  subjectName: string;
  maxMarks: number;
  marksObtained: number;
  facultyFeedback?: string;
  gradedAt: string;
}

export interface InternalMarkRecord {
  id: string;
  studentId: string;
  studentName: string;
  studentRollNo: string;
  subjectId: string;
  subjectName: string;
  testName: string; // e.g. "Internal Assessment 1 (IA-1)"
  maxMarks: number;
  marksObtained: number;
  date: string;
  facultyId: string;
  facultyName: string;
}

export interface SemesterMarkRecord {
  id: string;
  studentId: string;
  studentName: string;
  studentRollNo: string;
  subjectId: string;
  subjectName: string;
  semester: string; // e.g. "Semester VI", "Semester VII"
  maxMarks: number;
  marksObtained: number;
  grade: string; // e.g. "O", "A+", "A", "B+", "B"
  resultStatus: 'Pass' | 'Fail';
}

export type JobType = 'Full-Time' | 'Internship' | 'Placement Drive';

export interface JobPost {
  id: string;
  title: string;
  company: string;
  companyLogo?: string;
  recruiterId: string;
  description: string;
  requiredSkills: string[];
  mandatorySkills?: string[];
  minCGPA: number;
  maxBacklogs?: number;
  eligibleDepartments: string[];
  graduationYear: number;
  applicationDeadline: string; // YYYY-MM-DD
  jobType: JobType;
  location: string;
  salaryPackage: string; // e.g. "₹14 - 18 LPA" or "₹45,000/month"
  createdAt: string;
  isActive: boolean;
}

export type InterviewRoundStatus = 
  | 'Scheduled' 
  | 'In Progress' 
  | 'Selected' 
  | 'Rejected' 
  | 'On Hold' 
  | 'Rescheduled' 
  | 'Completed';

export type RejectionCategory = 
  | 'Skills mismatch'
  | 'Insufficient technical knowledge'
  | 'Communication skills'
  | 'Coding/technical assessment performance'
  | 'Experience mismatch'
  | 'Eligibility criteria not met'
  | 'Interview performance'
  | 'Other';

export interface RejectionFeedback {
  id: string;
  applicationId: string;
  interviewRoundId?: string;
  roundName?: string;
  recruiterId: string;
  recruiterName: string;
  companyName: string;
  category: RejectionCategory;
  feedback: string;
  rejectedAt: string; // ISO string
}

export interface InterviewRound {
  id: string;
  applicationId: string;
  roundNumber: number;
  roundName: string; // e.g. "Round 1: Online Technical Assessment"
  dateTime: string; // ISO string e.g. "2026-10-15T10:00"
  mode: 'Online (Google Meet)' | 'On-Campus (Placement Block)' | 'Hackerrank Platform' | 'Virtual Interview' | 'In-Person / Office';
  status: InterviewRoundStatus;
  meetingLinkOrVenue?: string;
  interviewer?: string;
  feedback?: string;
  rejectionReason?: string;
  rejectionFeedback?: RejectionFeedback;
  areasForImprovement?: string[];
  scheduledBy: string; // Recruiter or Placement Officer ID
  updatedAt: string;
}

export type ApplicationStatus = 
  | 'Applied' 
  | 'Under Review'
  | 'Shortlisted' 
  | 'Interview Scheduled'
  | 'Interviewing' 
  | 'Selected' 
  | 'Rejected' 
  | 'On Hold';

export interface Application {
  id: string;
  jobId: string;
  jobTitle: string;
  company: string;
  studentId: string;
  studentName: string;
  studentRollNo: string;
  studentDepartment: string;
  studentCGPA: number;
  studentSkills: string[];
  appliedDate: string;
  status: ApplicationStatus;
  interviewRounds: InterviewRound[];
  currentRoundName?: string;
  finalResult?: 'Selected' | 'Rejected' | 'Pending';
  coverLetter?: string;
  rejectionFeedback?: RejectionFeedback;
}

export interface PlacementDrive {
  id: string;
  jobId: string;
  company: string;
  role: string;
  driveDate: string;
  minCGPA: number;
  eligibleDepartments: string[];
  graduationYear: number;
  salaryPackage: string;
  status: 'Upcoming' | 'Active' | 'Completed';
  location: string;
  notes?: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  leadStudentId: string;
  leadStudentName: string;
  teamMembers: string[];
  guideFacultyName: string;
  guideFacultyId?: string;
  department: string;
  category: 'Capstone' | 'Research' | 'Industry Sponsored' | 'Mini-Project';
  status: 'In Progress' | 'Review Ready' | 'Completed' | 'Ideation';
  progressPercentage: number;
  milestones: {
    id: string;
    title: string;
    dueDate: string;
    completed: boolean;
  }[];
  githubUrl?: string;
}

export interface AppNotification {
  id: string;
  targetUserId: string; // user ID or role
  title: string;
  message: string;
  type: 'assignment' | 'attendance' | 'marks' | 'interview' | 'job' | 'system';
  link?: string;
  relatedRecordId?: string;
  read: boolean;
  createdAt: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  category: 'assignment' | 'exam' | 'interview' | 'placement' | 'project';
  date: string;
  time?: string;
  description?: string;
  targetRole?: UserRole | 'all';
}

export interface AIAgent {
  id: string;
  name: string;
  role: string;
  specialty: string;
  avatarColor: string;
  welcomeMessage: string;
  suggestedPrompts: string[];
}
