import { getGeminiClient, GEMINI_MODEL } from './geminiClient';
import { campusDb } from '../db';
import { RAGService } from '../rag';
import { User, Application, JobPost, AttendanceRecord, Assignment, Submission } from '../../types';

export interface ChatHistoryMessage {
  role: 'user' | 'model';
  text: string;
}

export interface AgentContextPayload {
  activeAgentId: string;
  retrievedEntities: string[];
  ragUsed: boolean;
  contextData: string;
}

export const MultiAgentOrchestrator = {
  /**
   * Coordinator Agent: Analyzes query and role to decide which domain agents
   * to dispatch, retrieves exact database slices, and formats grounded context.
   */
  coordinate(user: User, query: string): AgentContextPayload {
    const q = query.toLowerCase();
    const role = user.role;
    const retrievedEntities: string[] = [];
    let activeAgentId = 'coordinator';
    let contextData = `CURRENT AUTHENTICATED USER CONTEXT:\n- ID: ${user.id}\n- Name: ${user.name}\n- Role: ${user.role}\n`;

    if (user.department) contextData += `- Department: ${user.department}\n`;
    if (user.cgpa) contextData += `- Current CGPA: ${user.cgpa}\n`;
    if (user.rollNo) contextData += `- Roll No: ${user.rollNo}\n`;
    if (user.skills && user.skills.length > 0) contextData += `- Profile Skills: ${user.skills.join(', ')}\n`;
    if (user.companyName) contextData += `- Company: ${user.companyName}\n`;

    // -------------------------------------------------------------
    // ROLE: STUDENT
    // -------------------------------------------------------------
    if (role === 'student') {
      const isAttendance = /attendance|absent|present|classes|lecture|shortage|bunk|condonation/i.test(q);
      const isAcademic = /assignment|homework|submission|lab|internal|mark|grade|exam|cia|semester/i.test(q);
      const isCareer = /skill|learn|road\s*map|become|prepare|resume|project|certif|gap|stack/i.test(q);
      const isPlacement = /job|internship|company|opportunit|drive|eligible|eligibility|ctc|package|offer|dream/i.test(q);
      const isInterview = /interview|round|schedule|venue|panel|link|reject|feedback|status|application/i.test(q);
      const isPolicy = /rule|regulation|policy|handbook|dress|od|on\s*duty|debar|clause/i.test(q);

      // 1. Attendance Agent
      if (isAttendance || q.includes('how is my')) {
        activeAgentId = 'attendance-agent';
        retrievedEntities.push('attendance_records');
        const allAtt = campusDb.getAttendance();
        const studentAtt = allAtt.filter(
          a => a.studentId === user.id || (user.rollNo && a.studentRollNo === user.rollNo)
        );

        const subjects = Array.from(new Set(studentAtt.map(a => a.subject)));
        let totalClasses = studentAtt.length;
        let totalPresent = studentAtt.filter(a => a.status === 'present').length;
        let overallPct = totalClasses > 0 ? Math.round((totalPresent / totalClasses) * 100) : 100;

        contextData += `\n[ATTENDANCE AGENT DATABASE SLICE]\n`;
        contextData += `Overall Attendance: ${overallPct}% (${totalPresent} attended out of ${totalClasses} total lectures)\n`;
        contextData += `Mandatory Threshold: 75% minimum university requirement.\n`;
        contextData += `Subject Breakdown:\n`;

        subjects.forEach(sub => {
          const subRecords = studentAtt.filter(a => a.subject === sub);
          const present = subRecords.filter(a => a.status === 'present').length;
          const total = subRecords.length;
          const pct = total > 0 ? Math.round((present / total) * 100) : 100;
          const neededFor75 = Math.max(0, Math.ceil((0.75 * total - present) / 0.25));
          contextData += `  * ${sub}: ${pct}% (${present}/${total} classes). ${neededFor75 > 0 ? `Needs ${neededFor75} consecutive lectures to reach 75%.` : 'Compliant.'}\n`;
        });
      }

      // 2. Academic / Assignment Agent
      if (isAcademic || q.includes('pending') || q.includes('deadline')) {
        if (activeAgentId === 'coordinator') activeAgentId = 'academic-agent';
        retrievedEntities.push('assignments', 'submissions', 'internal_marks');
        const assignments = campusDb.getAssignments();
        const submissions = campusDb.getSubmissions().filter(
          s => s.studentId === user.id || (user.rollNo && s.studentRollNo === user.rollNo)
        );
        const internals = campusDb.getInternalMarks().filter(m => m.studentId === user.id);

        contextData += `\n[ACADEMIC & ASSIGNMENT AGENT DATABASE SLICE]\n`;
        contextData += `Assignments Tracked (${assignments.length} total):\n`;
        assignments.forEach(asg => {
          const sub = submissions.find(s => s.assignmentId === asg.id);
          const status = sub ? (sub.status === 'graded' ? `Graded (${sub.marksObtained}/${asg.maxMarks})` : 'Submitted (Under Review)') : 'PENDING NOT SUBMITTED';
          contextData += `  * ${asg.title} (${asg.subject}) - Due: ${asg.dueDate} ${asg.dueTime} - Status: ${status} - Max Marks: ${asg.maxMarks}\n`;
        });

        if (internals.length > 0) {
          contextData += `Internal Assessment Scores:\n`;
          internals.forEach(im => {
            contextData += `  * ${im.subjectName} (${im.testName}): ${im.marksObtained}/${im.maxMarks}\n`;
          });
        }
      }

      // 3. Career & Skill Gap Agent
      if (isCareer) {
        if (activeAgentId === 'coordinator') activeAgentId = 'career-agent';
        retrievedEntities.push('resume_data', 'skills');
        const resumeSkills = user.resume?.extractedSkills || user.skills || [];
        const projects = campusDb.getProjects().filter(p => p.leadStudentId === user.id || p.teamMembers?.includes(user.name));

        contextData += `\n[CAREER & SKILL GAP AGENT DATABASE SLICE]\n`;
        contextData += `Verified Student Resume Skills: [${resumeSkills.join(', ')}]\n`;
        if (user.resume?.experience) {
          contextData += `Experience: ${user.resume.experience.map(e => `${e.role} at ${e.company}`).join(', ')}\n`;
        }
        if (projects.length > 0) {
          contextData += `Student Projects:\n`;
          projects.forEach(p => {
            contextData += `  * ${p.title} (${p.category}): ${p.description}\n`;
          });
        }
      }

      // 4. Internship & Placement Agent
      if (isPlacement) {
        if (activeAgentId === 'coordinator') activeAgentId = 'placement-agent';
        retrievedEntities.push('job_posts', 'placement_drives');
        const jobs = campusDb.getJobPosts();
        contextData += `\n[INTERNSHIP & PLACEMENT AGENT DATABASE SLICE]\n`;
        contextData += `Active Campus Opportunities (${jobs.length} open drives):\n`;
        jobs.slice(0, 6).forEach(j => {
          const isCgpaEligible = !j.minCGPA || (user.cgpa || 0) >= j.minCGPA;
          const isDeptEligible = !j.eligibleDepartments || j.eligibleDepartments.some(d => d.toLowerCase().includes((user.department || '').toLowerCase()));
          const isEligible = isCgpaEligible && isDeptEligible;
          contextData += `  * ${j.title} at ${j.company} (CTC: ${j.salaryPackage || 'Competitive'}, Min CGPA: ${j.minCGPA}, Required: [${j.requiredSkills.join(', ')}]) - Eligibility for student: ${isEligible ? 'ELIGIBLE' : 'INELIGIBLE'}\n`;
        });
      }

      // 5. Interview & Rejection Feedback Agent
      if (isInterview || q.includes('why') || q.includes('reject') || q.includes('application')) {
        if (activeAgentId === 'coordinator') activeAgentId = 'interview-agent';
        retrievedEntities.push('applications', 'interview_rounds', 'rejection_feedback');
        const applications = campusDb.getApplications().filter(
          a => a.studentId === user.id || (user.rollNo && a.studentRollNo === user.rollNo)
        );

        contextData += `\n[INTERVIEW & APPLICATION AGENT DATABASE SLICE]\n`;
        contextData += `Student Submitted Applications (${applications.length} total):\n`;
        applications.forEach(app => {
          contextData += `  * ${app.company} - ${app.jobTitle} - Overall Status: ${app.status} (Applied: ${app.appliedDate})\n`;
          if (app.interviewRounds && app.interviewRounds.length > 0) {
            contextData += `    Interview Rounds:\n`;
            app.interviewRounds.forEach(r => {
              contextData += `      - Round ${r.roundNumber} (${r.roundName}): Status: ${r.status}, Date: ${r.dateTime}, Mode: ${r.mode}, Panel: ${r.interviewer || 'TBD'}\n`;
              if (r.feedback) contextData += `        Round Feedback: "${r.feedback}"\n`;
              if (r.rejectionFeedback) {
                contextData += `        REJECTION FEEDBACK: Category: ${r.rejectionFeedback.category}, Note: "${r.rejectionFeedback.feedback}"\n`;
              }
            });
          }
          if (app.status === 'Rejected') {
            if (app.rejectionFeedback) {
              contextData += `    REJECTION REASON (Recruiter Provided): Category: [${app.rejectionFeedback.category}], Detailed Feedback: "${app.rejectionFeedback.feedback}"\n`;
            } else {
              contextData += `    REJECTION NOTE: No detailed feedback has been provided by the recruiter.\n`;
            }
          }
        });
      }
    }

    // -------------------------------------------------------------
    // ROLE: FACULTY
    // -------------------------------------------------------------
    else if (role === 'faculty') {
      activeAgentId = 'faculty-analytics-agent';
      retrievedEntities.push('faculty_classes', 'attendance', 'assignments', 'submissions');
      const allUsers = campusDb.getUsers().filter(u => u.role === 'student');
      const allAtt = campusDb.getAttendance();
      const allAsg = campusDb.getAssignments().filter(a => a.facultyId === user.id || a.facultyName === user.name);
      const allSubs = campusDb.getSubmissions();

      contextData += `\n[FACULTY ANALYTICS AGENT DATABASE SLICE]\n`;
      contextData += `Total Enrolled Department Students: ${allUsers.length}\n`;

      // Low attendance analysis
      const lowAttendanceStudents: Array<{ name: string; rollNo: string; pct: number }> = [];
      allUsers.forEach(s => {
        const sAtt = allAtt.filter(a => a.studentId === s.id);
        const present = sAtt.filter(a => a.status === 'present').length;
        const total = sAtt.length;
        const pct = total > 0 ? Math.round((present / total) * 100) : 100;
        if (pct < 75 && total > 0) {
          lowAttendanceStudents.push({ name: s.name, rollNo: (s as any).rollNo || 'N/A', pct });
        }
      });

      contextData += `Students with Attendance Shortage (<75%):\n`;
      if (lowAttendanceStudents.length === 0) {
        contextData += `  * None. All active students have 75% or higher attendance.\n`;
      } else {
        lowAttendanceStudents.forEach(st => {
          contextData += `  * ${st.name} (${st.rollNo}): ${st.pct}% attendance (CRITICAL SHORTAGE)\n`;
        });
      }

      // Coursework & Submissions
      contextData += `Assignments Posted by this Faculty:\n`;
      allAsg.forEach(asg => {
        const subs = allSubs.filter(s => s.assignmentId === asg.id);
        const graded = subs.filter(s => s.status === 'graded');
        const pendingGrading = subs.filter(s => s.status === 'submitted');
        contextData += `  * ${asg.title} (${asg.subject}): ${subs.length} submitted, ${graded.length} graded, ${pendingGrading.length} pending grading, ${Math.max(0, allUsers.length - subs.length)} unsubmitted.\n`;
      });
    }

    // -------------------------------------------------------------
    // ROLE: RECRUITER
    // -------------------------------------------------------------
    else if (role === 'recruiter') {
      activeAgentId = 'recruiter-applicant-agent';
      retrievedEntities.push('job_posts', 'applicants', 'interview_rounds');
      const company = (user.companyName || '').toLowerCase();
      const myJobs = campusDb.getJobPosts().filter(
        j => j.recruiterId === user.id || (company && j.company.toLowerCase().includes(company))
      );
      const myJobIds = new Set(myJobs.map(j => j.id));
      const myApps = campusDb.getApplications().filter(a => myJobIds.has(a.jobId));

      contextData += `\n[RECRUITER HIRING PIPELINE DATABASE SLICE]\n`;
      contextData += `Active Job Postings (${myJobs.length}):\n`;
      myJobs.forEach(j => {
        const appsForJob = myApps.filter(a => a.jobId === j.id);
        contextData += `  * ${j.title} (ID: ${j.id}) - Required Skills: [${j.requiredSkills.join(', ')}] - Total Applicants: ${appsForJob.length}\n`;
      });

      contextData += `Candidate Applicants Breakdown (${myApps.length} applicants):\n`;
      myApps.forEach(a => {
        const job = myJobs.find(j => j.id === a.jobId);
        const reqSkills = job?.requiredSkills || [];
        const matched = reqSkills.filter(req => (a.studentSkills || []).some(s => s.toLowerCase().includes(req.toLowerCase())));
        const matchPct = reqSkills.length > 0 ? Math.round((matched.length / reqSkills.length) * 100) : 80;
        contextData += `  * ${a.studentName} (${a.studentDepartment}, CGPA: ${a.studentCGPA}) applied for ${a.jobTitle} - Status: ${a.status} - Skill Match: ${matchPct}% (Skills: [${(a.studentSkills || []).join(', ')}])\n`;
      });
    }

    // -------------------------------------------------------------
    // ROLE: PLACEMENT CELL
    // -------------------------------------------------------------
    else if (role === 'placement') {
      activeAgentId = 'placement-cell-analytics-agent';
      retrievedEntities.push('placement_analytics', 'departments', 'companies', 'applications');
      const allApps = campusDb.getApplications();
      const allJobs = campusDb.getJobPosts();
      const allStudents = campusDb.getUsers().filter(u => u.role === 'student');
      const placedApps = allApps.filter(a => a.status === 'Selected');
      const placedStudentIds = new Set(placedApps.map(a => a.studentId));

      contextData += `\n[PLACEMENT CELL INSTITUTIONAL ANALYTICS DATABASE SLICE]\n`;
      contextData += `Total Registered Students: ${allStudents.length}\n`;
      contextData += `Total Job Listings: ${allJobs.length}\n`;
      contextData += `Total Submitted Applications: ${allApps.length}\n`;
      contextData += `Total Placed / Offers Secured: ${placedStudentIds.size} (${allStudents.length > 0 ? Math.round((placedStudentIds.size / allStudents.length) * 100) : 0}% placement rate)\n`;

      // Department breakdown
      const deptMap = new Map<string, { total: number; placed: number }>();
      allStudents.forEach(s => {
        const dept = s.department || 'Computer Science';
        if (!deptMap.has(dept)) deptMap.set(dept, { total: 0, placed: 0 });
        const cur = deptMap.get(dept)!;
        cur.total += 1;
        if (placedStudentIds.has(s.id)) cur.placed += 1;
      });

      contextData += `Department-wise Placement Performance:\n`;
      deptMap.forEach((v, dept) => {
        const pct = v.total > 0 ? Math.round((v.placed / v.total) * 100) : 0;
        contextData += `  * ${dept}: ${v.placed}/${v.total} placed (${pct}%)\n`;
      });
    }

    // -------------------------------------------------------------
    // RAG INSTITUTIONAL POLICIES CHECK
    // -------------------------------------------------------------
    const ragDocs = RAGService.search(query, 3);
    const ragUsed = ragDocs.length > 0;
    if (ragUsed) {
      retrievedEntities.push('rag_institutional_handbook');
      contextData += RAGService.formatForContext(ragDocs);
    }

    return {
      activeAgentId,
      retrievedEntities,
      ragUsed,
      contextData
    };
  },

  /**
   * Generates a grounded AI response using the Gemini 3.8 Flash model.
   */
  async processQuery(
    user: User,
    userQuery: string,
    history: ChatHistoryMessage[] = []
  ): Promise<{ text: string; agentId: string; retrievedEntities: string[]; ragUsed: boolean }> {
    const { activeAgentId, retrievedEntities, ragUsed, contextData } = this.coordinate(user, userQuery);

    const systemInstruction = `You are the Multi-Agent AI Intelligence Engine for the "Campus Productivity, Academic, Internship and Placement Management System".
Your current role persona is specialized for: [${user.role.toUpperCase()} USER: ${user.name}].
Active Dispatch Agent: ${activeAgentId}.

STRICT GROUNDING & BEHAVIORAL MANDATES:
1. You have been provided with REAL, AUTHENTIC database records and institutional handbook documents in your context.
2. ANSWER USING ACTUAL CURRENT DATA ONLY:
   - Calculate percentages, counts, and statuses directly from the provided database slice.
   - Do NOT invent student records, grades, marks, attendance percentages, or job postings.
   - Do NOT invent recruiter feedback. If an applicant was rejected and recruiter feedback is present, cite the exact reason category and feedback string. If no feedback is present, say "No detailed feedback has been provided by the recruiter."
   - For institutional campus rules, quote or reference the official clauses from the RAG handbook sections provided.
3. If the user asks for career roadmap or missing skills:
   - Compare the student's actual resume skills against the role or job requirements.
   - List precisely what skills they have (matched) and what skills they lack (missing).
4. Tone & Formatting:
   - Provide structured, professional, well-organized responses with Markdown bolding, bullet points, and clear headers.
   - Be constructive, encouraging, and accurate.
5. If information requested is not in the database or RAG store, honestly state that it is not available in current records.`;

    try {
      const ai = getGeminiClient();

      // Format previous conversation history for chat continuity
      const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

      // Add recent history messages (up to 6)
      const recentHistory = history.slice(-6);
      recentHistory.forEach(h => {
        contents.push({
          role: h.role,
          parts: [{ text: h.text }]
        });
      });

      // Add current query with structured database context
      const promptWithContext = `USER QUESTION:
"${userQuery}"

--- RETRIEVED REAL-TIME CONTEXT FROM MULTI-AGENT DATASTORE ---
${contextData}
--- END CONTEXT ---

Please answer the user's question directly based strictly on the above verified data.`;

      contents.push({
        role: 'user',
        parts: [{ text: promptWithContext }]
      });

      const response = await ai.models.generateContent({
        model: GEMINI_MODEL,
        contents,
        config: {
          systemInstruction
        }
      });

      const replyText = response.text || 'I analyzed your request against the campus records, but no text was returned.';

      return {
        text: replyText,
        agentId: activeAgentId,
        retrievedEntities,
        ragUsed
      };
    } catch (err: any) {
      console.error('Error calling Gemini model:', err);
      // Fallback with data-grounded summary if external API fails
      return {
        text: `⚠️ *Notice: AI server encountered a transient network connection error (${err.message || 'Gemini API call'}). Below is the verified real-time database record for your inquiry:*\n\n${contextData}`,
        agentId: activeAgentId,
        retrievedEntities,
        ragUsed
      };
    }
  }
};
