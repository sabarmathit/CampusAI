import { GoogleGenAI } from '@google/genai';

let aiInstance: GoogleGenAI | null = null;

export function getGeminiClient(): GoogleGenAI {
  if (!aiInstance) {
    // Reads GEMINI_API_KEY from environment automatically
    aiInstance = new GoogleGenAI();
  }
  return aiInstance;
}

export const GEMINI_MODEL = 'gemini-3.8-flash';
