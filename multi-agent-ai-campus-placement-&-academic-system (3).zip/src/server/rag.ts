/**
 * Institutional RAG Knowledge Base for College Regulations, Placement Guidelines,
 * Attendance Policies, and Academic Handbooks.
 */

export interface InstitutionalDocChunk {
  id: string;
  category: 'academic_regulations' | 'placement_policy' | 'examination_grading' | 'leave_attendance' | 'department_guidelines';
  title: string;
  content: string;
  keywords: string[];
}

export const INSTITUTIONAL_KNOWLEDGE_BASE: InstitutionalDocChunk[] = [
  {
    id: 'rag-acad-01',
    category: 'leave_attendance',
    title: 'University Attendance Mandate & 75% Condonation Policy',
    content: `According to University Academic Regulation Clause 4.2:
1. Every candidate must secure a minimum aggregate attendance of 75% in each registered theory and laboratory subject to be eligible to appear for the End Semester Examinations.
2. Condonation of shortage of attendance up to 10% (i.e., between 65% and 74.9%) may be granted by the College Academic Council exclusively on valid medical grounds (certified hospitalization) or official On-Duty (OD) participation in university-authorized sports/conferences.
3. Candidates having attendance below 65% are NOT eligible for condonation under any circumstances. They shall be deemed 'Debarred / Detained' for that semester and must re-register for the course in subsequent cycles.
4. Consecutive absence for more than 3 working days without prior written sanction from the Head of the Department (HOD) leads to automatic administrative warning.`,
    keywords: ['attendance', '75%', 'shortage', 'absent', 'condonation', 'medical leave', 'debarred', 'eligible exam', 'leave']
  },
  {
    id: 'rag-acad-02',
    category: 'examination_grading',
    title: 'Evaluation Criteria, Internal Assessments & CGPA Scale',
    content: `Academic Assessment Regulations Clause 6.1:
1. The evaluation of every course consists of two components: Continuous Internal Assessment (CIA) carrying 40% weightage, and End Semester Examination (ESE) carrying 60% weightage.
2. Continuous Internal Assessment comprises two Mid-Semester Tests (20 marks each), Course Assignment/Mini-Project (10 marks), and Class Quizzes/Tutorials (10 marks), scaled to 40 marks.
3. A student must score a minimum of 45% in the End Semester Examination and an aggregate (Internal + External) of 50% to pass the course.
4. Cumulative Grade Point Average (CGPA) is computed on a 10.0 scale. First Class with Distinction requires a minimum CGPA of 8.50 with no backlogs throughout the degree program. First Class requires CGPA of 7.00.`,
    keywords: ['internal marks', 'cia', 'cgpa', 'mid term', 'grade', 'passing mark', 'weightage', 'distinction', 'backlog']
  },
  {
    id: 'rag-place-01',
    category: 'placement_policy',
    title: 'Campus Placement Eligibility, Registration & Code of Conduct',
    content: `Placement Cell Policy Document (Clause 3 - Student Rights & Duties):
1. Eligibility: Only students who have registered with the Central Placement Office, verified their academic credentials, uploaded an approved resume, and have no active disciplinary inquiries are allowed to participate in campus recruitment.
2. Punctuality & Attendance: Once shortlisted for a company drive (written test, group discussion, or interview), attendance is MANDATORY. Failure to appear for a scheduled interview without 24-hour advance written notice to the Placement Director results in immediate suspension from the subsequent 2 placement drives.
3. Dress Code: Formal business attire is strictly required for all physical and virtual interview rounds. Formal shoes, college ID card, and physical copies of resume are required.
4. Offer Acceptance: A student receiving an offer is given 48 hours to confirm acceptance. Failure to accept within the deadline results in revocation of the offer to the waitlisted candidate.`,
    keywords: ['placement rules', 'dress code', 'registered', 'interview rules', 'missed interview', 'mandatory attendance', 'placement policy', 'placement cell']
  },
  {
    id: 'rag-place-02',
    category: 'placement_policy',
    title: 'Dream & Super-Dream Job Offers Policy',
    content: `Placement Cell Policy Document (Clause 7 - Categorization of Job Offers):
1. Regular / Core Offers: Packages below 8.0 LPA.
2. Dream Company Offers: Packages between 8.0 LPA and 15.0 LPA.
3. Super Dream Company Offers: Packages of 15.0 LPA and above.
4. "One Student, One Job" Standard Rule: Once a student receives a Regular Offer (< 8.0 LPA), they are permitted to appear ONLY for Dream or Super-Dream companies.
5. Once a candidate secures a Dream Offer (8 - 15 LPA), they are eligible to participate ONLY in Super-Dream drives (>= 15 LPA).
6. Once a student receives a Super-Dream Offer (>= 15 LPA), they are marked as 'Fully Placed' and cannot apply for any further on-campus drives to ensure fair opportunity for peers.`,
    keywords: ['dream offer', 'super dream', 'ctc', 'package', 'one student one job', 'multiple offers', 'placement eligibility', 'salary']
  },
  {
    id: 'rag-acad-03',
    category: 'leave_attendance',
    title: 'On-Duty (OD) Sanctions, Hackathons & Technical Competitions',
    content: `Academic Council Guidelines on Technical Symposia and Hackathons:
1. Students participating in external hackathons (e.g., Smart India Hackathon, SIH, national coding events) are eligible for academic On-Duty (OD) up to a maximum of 10 working days per academic year.
2. The OD request must be submitted with official invitation proof to the Faculty Advisor and approved by the HOD at least 3 days prior to the event.
3. Approved OD is counted as 'Present' in lecture attendance calculations and does not penalize semester exam eligibility.`,
    keywords: ['on duty', 'od', 'hackathon', 'competition', 'absence', 'permission', 'symposium', 'leave approval']
  },
  {
    id: 'rag-dept-01',
    category: 'department_guidelines',
    title: 'Final-Year Capstone Project Guidelines & Review Milestones',
    content: `Departmental Project Committee Regulations (CS804 / Final Year Capstone):
1. Every final-year student must register a project topic in teams of 2 to 4 members or individually by Phase 1 deadline.
2. Mandatory Review Schedule:
   - Review 0: Problem Formulation & Literature Review (Semester 7, Week 4) - 10 Marks
   - Review 1: Architecture, Design Specifications & Schema (Semester 7, Week 10) - 20 Marks
   - Review 2: Mid-Implementation & Unit Testing (Semester 8, Week 6) - 30 Marks
   - Review 3: Final Demo, Deployment & Plagiarism Check (<15% similarity mandate) - 40 Marks
3. External Viva-Voce examination is conducted by an industry/university expert panel.`,
    keywords: ['project', 'capstone', 'review', 'viva', 'plagiarism', 'team', 'final year project', 'phase']
  }
];

export const RAGService = {
  /**
   * Search institutional documents for relevant clauses given a natural language query.
   */
  search(query: string, maxResults: number = 3): InstitutionalDocChunk[] {
    const q = query.toLowerCase();
    const queryTokens = q.split(/\W+/).filter(t => t.length > 2);

    const scored = INSTITUTIONAL_KNOWLEDGE_BASE.map(doc => {
      let score = 0;

      // Check keywords
      doc.keywords.forEach(kw => {
        if (q.includes(kw.toLowerCase())) {
          score += 5;
        }
      });

      // Check content match
      queryTokens.forEach(token => {
        if (doc.title.toLowerCase().includes(token)) score += 3;
        if (doc.content.toLowerCase().includes(token)) score += 1;
      });

      return { doc, score };
    });

    return scored
      .filter(item => item.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, maxResults)
      .map(item => item.doc);
  },

  formatForContext(chunks: InstitutionalDocChunk[]): string {
    if (chunks.length === 0) return '';
    let text = `\n--- OFFICIAL INSTITUTIONAL HANDBOOK & POLICIES (RAG RETRIEVAL) ---\n`;
    chunks.forEach((c, idx) => {
      text += `[DOCUMENT ${idx + 1}: ${c.title} (${c.category})]\n${c.content}\n\n`;
    });
    text += `--- END INSTITUTIONAL HANDBOOK ---\n`;
    return text;
  }
};
