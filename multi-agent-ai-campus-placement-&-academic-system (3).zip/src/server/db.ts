import fs from 'fs';
import path from 'path';
import { 
  User, 
  Subject, 
  Assignment, 
  Submission, 
  AttendanceRecord, 
  InternalMarkRecord, 
  SemesterMarkRecord, 
  JobPost, 
  Application, 
  PlacementDrive, 
  Project, 
  AppNotification, 
  CalendarEvent,
  InterviewRound,
  ApplicationStatus,
  RejectionCategory,
  RejectionFeedback,
  ResumeData
} from '../types';
import {
  INITIAL_USERS,
  INITIAL_SUBJECTS,
  INITIAL_ASSIGNMENTS,
  INITIAL_SUBMISSIONS,
  INITIAL_ATTENDANCE,
  INITIAL_INTERNAL_MARKS,
  INITIAL_SEMESTER_MARKS,
  INITIAL_JOB_POSTS,
  INITIAL_APPLICATIONS,
  INITIAL_PLACEMENT_DRIVES,
  INITIAL_PROJECTS,
  INITIAL_NOTIFICATIONS,
  INITIAL_CALENDAR_EVENTS
} from '../data/mockData';

export interface CampusDatabaseSchema {
  users: User[];
  subjects: Subject[];
  assignments: Assignment[];
  submissions: Submission[];
  attendance: AttendanceRecord[];
  internalMarks: InternalMarkRecord[];
  semesterMarks: SemesterMarkRecord[];
  jobPosts: JobPost[];
  applications: Application[];
  placementDrives: PlacementDrive[];
  projects: Project[];
  notifications: AppNotification[];
  calendarEvents: CalendarEvent[];
}

const DB_FILE_PATH = path.resolve(process.cwd(), 'campus_data_store.json');

class CampusDatabase {
  private data: CampusDatabaseSchema;
  private listeners: Array<(entity: string, data: any) => void> = [];

  constructor() {
    this.data = this.loadDatabase();
  }

  private loadDatabase(): CampusDatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE_PATH)) {
        const raw = fs.readFileSync(DB_FILE_PATH, 'utf-8');
        const parsed = JSON.parse(raw);
        // Ensure all top-level keys exist
        return {
          users: parsed.users || INITIAL_USERS,
          subjects: parsed.subjects || INITIAL_SUBJECTS,
          assignments: parsed.assignments || INITIAL_ASSIGNMENTS,
          submissions: parsed.submissions || INITIAL_SUBMISSIONS,
          attendance: parsed.attendance || INITIAL_ATTENDANCE,
          internalMarks: parsed.internalMarks || INITIAL_INTERNAL_MARKS,
          semesterMarks: parsed.semesterMarks || INITIAL_SEMESTER_MARKS,
          jobPosts: parsed.jobPosts || INITIAL_JOB_POSTS,
          applications: parsed.applications || INITIAL_APPLICATIONS,
          placementDrives: parsed.placementDrives || INITIAL_PLACEMENT_DRIVES,
          projects: parsed.projects || INITIAL_PROJECTS,
          notifications: parsed.notifications || INITIAL_NOTIFICATIONS,
          calendarEvents: parsed.calendarEvents || INITIAL_CALENDAR_EVENTS,
        };
      }
    } catch (err) {
      console.error('Failed to load campus database from file, using initial dataset:', err);
    }

    const initial: CampusDatabaseSchema = {
      users: INITIAL_USERS,
      subjects: INITIAL_SUBJECTS,
      assignments: INITIAL_ASSIGNMENTS,
      submissions: INITIAL_SUBMISSIONS,
      attendance: INITIAL_ATTENDANCE,
      internalMarks: INITIAL_INTERNAL_MARKS,
      semesterMarks: INITIAL_SEMESTER_MARKS,
      jobPosts: INITIAL_JOB_POSTS,
      applications: INITIAL_APPLICATIONS,
      placementDrives: INITIAL_PLACEMENT_DRIVES,
      projects: INITIAL_PROJECTS,
      notifications: INITIAL_NOTIFICATIONS,
      calendarEvents: INITIAL_CALENDAR_EVENTS,
    };
    this.persist(initial);
    return initial;
  }

  private persist(dataToSave?: CampusDatabaseSchema): void {
    try {
      const data = dataToSave || this.data;
      fs.writeFileSync(DB_FILE_PATH, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to persist database file:', err);
    }
  }

  public subscribe(listener: (entity: string, data: any) => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notify(entity: string, data: any) {
    this.listeners.forEach(fn => {
      try {
        fn(entity, data);
      } catch (err) {
        console.error('Error notifying DB listener:', err);
      }
    });
  }

  // --- Users ---
  getUsers(): User[] {
    return this.data.users;
  }

  getUserById(id: string): User | undefined {
    return this.data.users.find(u => u.id === id);
  }

  saveUser(user: User): User {
    const idx = this.data.users.findIndex(u => u.id === user.id);
    if (idx >= 0) {
      this.data.users[idx] = { ...this.data.users[idx], ...user };
    } else {
      this.data.users.push(user);
    }
    this.persist();
    this.notify('users', user);
    return user;
  }

  // --- Subjects ---
  getSubjects(): Subject[] {
    return this.data.subjects;
  }

  // --- Attendance ---
  getAttendance(): AttendanceRecord[] {
    return this.data.attendance;
  }

  saveAttendanceBatch(records: Omit<AttendanceRecord, 'id'>[]): AttendanceRecord[] {
    const savedRecords: AttendanceRecord[] = [];
    const timestamp = new Date().toISOString();

    records.forEach(rec => {
      const existingIdx = this.data.attendance.findIndex(
        a => a.studentId === rec.studentId && a.subject === rec.subject && a.date === rec.date
      );

      if (existingIdx >= 0) {
        this.data.attendance[existingIdx] = {
          ...this.data.attendance[existingIdx],
          ...rec,
          id: this.data.attendance[existingIdx].id
        };
        savedRecords.push(this.data.attendance[existingIdx]);
      } else {
        const newRecord: AttendanceRecord = {
          ...rec,
          id: `att-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`
        };
        this.data.attendance.push(newRecord);
        savedRecords.push(newRecord);
      }

      // If absent, dispatch a real notification to the student
      if (rec.status === 'absent') {
        this.createNotification({
          targetUserId: rec.studentId,
          title: `Attendance Marked: Absent in ${rec.subject}`,
          message: `You were marked Absent for ${rec.subject} on ${rec.date} by ${rec.facultyName}. Maintain 75% attendance to prevent exam debarment.`,
          type: 'attendance',
          link: '/academics?tab=attendance'
        });
      }
    });

    this.persist();
    this.notify('attendance', savedRecords);
    return savedRecords;
  }

  // --- Assignments & Submissions ---
  getAssignments(): Assignment[] {
    return this.data.assignments;
  }

  createAssignment(asg: Omit<Assignment, 'id' | 'createdAt'>): Assignment {
    const newAsg: Assignment = {
      ...asg,
      id: `asg-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString()
    };
    this.data.assignments.unshift(newAsg);
    this.persist();
    this.notify('assignments', newAsg);

    // Notify enrolled students
    this.data.users
      .filter(u => u.role === 'student' && (!asg.department || u.department === asg.department))
      .forEach(student => {
        this.createNotification({
          targetUserId: student.id,
          title: `New Assignment: ${newAsg.title}`,
          message: `${newAsg.facultyName} posted an assignment for ${newAsg.subject}. Due: ${newAsg.dueDate}.`,
          type: 'assignment',
          relatedRecordId: newAsg.id,
          link: '/academics?tab=assignments'
        });
      });

    return newAsg;
  }

  getSubmissions(): Submission[] {
    return this.data.submissions;
  }

  saveSubmission(submission: Omit<Submission, 'id' | 'submittedAt'>): Submission {
    const existingIdx = this.data.submissions.findIndex(
      s => s.assignmentId === submission.assignmentId && s.studentId === submission.studentId
    );

    const fullSub: Submission = {
      ...submission,
      id: existingIdx >= 0 ? this.data.submissions[existingIdx].id : `sub-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      submittedAt: new Date().toISOString()
    };

    if (existingIdx >= 0) {
      this.data.submissions[existingIdx] = fullSub;
    } else {
      this.data.submissions.push(fullSub);
    }

    this.persist();
    this.notify('submissions', fullSub);

    // Notify faculty
    const asg = this.data.assignments.find(a => a.id === submission.assignmentId);
    if (asg) {
      this.createNotification({
        targetUserId: asg.facultyId,
        title: `Assignment Submission Received`,
        message: `${submission.studentName} submitted work for ${asg.title}.`,
        type: 'assignment',
        relatedRecordId: fullSub.id,
        link: '/academics?tab=assignments'
      });
    }

    return fullSub;
  }

  gradeSubmission(submissionId: string, marksObtained: number, feedback?: string): Submission {
    const sub = this.data.submissions.find(s => s.id === submissionId);
    if (!sub) throw new Error('Submission not found');

    sub.status = 'graded';
    sub.marksObtained = marksObtained;
    sub.feedback = feedback;

    this.persist();
    this.notify('submissions', sub);

    const asg = this.data.assignments.find(a => a.id === sub.assignmentId);
    this.createNotification({
      targetUserId: sub.studentId,
      title: `Assignment Graded: ${asg?.title || 'Coursework'}`,
      message: `Your submission was graded: ${marksObtained} Marks. ${feedback ? `Feedback: "${feedback}"` : ''}`,
      type: 'marks',
      relatedRecordId: sub.id,
      link: '/academics?tab=assignments'
    });

    return sub;
  }

  // --- Marks ---
  getInternalMarks(): InternalMarkRecord[] {
    return this.data.internalMarks;
  }

  getSemesterMarks(): SemesterMarkRecord[] {
    return this.data.semesterMarks;
  }

  // --- Jobs & Opportunities ---
  getJobPosts(): JobPost[] {
    return this.data.jobPosts;
  }

  createJobPost(job: Omit<JobPost, 'id' | 'createdAt' | 'isActive'>): JobPost {
    const newJob: JobPost = {
      ...job,
      id: `job-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
      isActive: true,
      salaryPackage: job.salaryPackage || 'Competitive'
    };

    this.data.jobPosts.unshift(newJob);
    this.persist();
    this.notify('jobPosts', newJob);

    // Notify placement cell and matching students
    this.data.users
      .filter(u => u.role === 'placement')
      .forEach(placementUser => {
        this.createNotification({
          targetUserId: placementUser.id,
          title: `New Job Opening Posted: ${newJob.title}`,
          message: `${newJob.company} created an opening with package of ${newJob.salaryPackage}.`,
          type: 'job',
          relatedRecordId: newJob.id,
          link: '/opportunities'
        });
      });

    return newJob;
  }

  // --- Applications ---
  getApplications(): Application[] {
    return this.data.applications;
  }

  getApplicationById(id: string): Application | undefined {
    return this.data.applications.find(a => a.id === id);
  }

  applyForJob(params: {
    jobId: string;
    studentId: string;
    coverLetter?: string;
  }): Application {
    const job = this.data.jobPosts.find(j => j.id === params.jobId);
    if (!job) throw new Error('Job listing not found');

    const student = this.data.users.find(u => u.id === params.studentId);
    if (!student) throw new Error('Student profile not found');

    // Prevent duplicate application
    const existing = this.data.applications.find(
      a => a.jobId === params.jobId && a.studentId === params.studentId
    );
    if (existing) {
      throw new Error('You have already applied for this position.');
    }

    const newApp: Application = {
      id: `app-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      jobId: job.id,
      jobTitle: job.title,
      company: job.company,
      studentId: student.id,
      studentName: student.name,
      studentRollNo: (student as any).rollNo || '21CS101',
      studentDepartment: student.department || 'Computer Science & Engineering',
      studentCGPA: student.cgpa || 8.0,
      studentSkills: student.skills || [],
      appliedDate: new Date().toISOString().split('T')[0],
      status: 'Applied',
      interviewRounds: [],
      coverLetter: params.coverLetter
    };

    this.data.applications.unshift(newApp);
    this.persist();
    this.notify('applications', newApp);

    // Notify Recruiter
    if (job.recruiterId) {
      this.createNotification({
        targetUserId: job.recruiterId,
        title: `New Candidate Application: ${newApp.jobTitle}`,
        message: `${newApp.studentName} (${newApp.studentDepartment}, CGPA: ${newApp.studentCGPA}) applied for ${newApp.jobTitle}.`,
        type: 'interview',
        relatedRecordId: newApp.id,
        link: '/applicants'
      });
    }

    // Confirmation to Student
    this.createNotification({
      targetUserId: student.id,
      title: `Application Submitted: ${job.title}`,
      message: `Your application for ${job.title} at ${job.company} has been received and forwarded to the recruiter.`,
      type: 'job',
      relatedRecordId: newApp.id,
      link: '/applications'
    });

    return newApp;
  }

  updateApplicationStatus(applicationId: string, status: ApplicationStatus): Application {
    const app = this.data.applications.find(a => a.id === applicationId);
    if (!app) throw new Error('Application not found');

    app.status = status;
    this.persist();
    this.notify('applications', app);

    this.createNotification({
      targetUserId: app.studentId,
      title: `Application Status Updated: ${status}`,
      message: `Your application for ${app.jobTitle} at ${app.company} has moved to "${status}".`,
      type: 'job',
      relatedRecordId: app.id,
      link: '/applications'
    });

    return app;
  }

  rejectApplication(
    applicationId: string,
    category: RejectionCategory,
    feedback: string,
    recruiterId?: string
  ): Application {
    const app = this.data.applications.find(a => a.id === applicationId);
    if (!app) throw new Error('Application not found');

    const rejectionData: RejectionFeedback = {
      id: `rej-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      category,
      feedback: feedback.trim(),
      recruiterId: recruiterId || 'rec-01',
      recruiterName: 'Recruiter',
      companyName: app.company,
      rejectedAt: new Date().toISOString(),
      applicationId: app.id
    };

    app.status = 'Rejected';
    app.rejectionFeedback = rejectionData;

    this.persist();
    this.notify('applications', app);

    this.createNotification({
      targetUserId: app.studentId,
      title: `Application Update: ${app.company} - ${app.jobTitle}`,
      message: `Your application was not selected. Category: ${category}. Recruiter Feedback: "${feedback.trim()}".`,
      type: 'job',
      relatedRecordId: app.id,
      link: '/applications'
    });

    return app;
  }

  // --- Interview Scheduling & Rounds ---
  scheduleInterviewRound(
    applicationId: string,
    roundData: Omit<InterviewRound, 'id' | 'applicationId' | 'roundNumber' | 'status' | 'createdAt'>
  ): InterviewRound {
    const app = this.data.applications.find(a => a.id === applicationId);
    if (!app) throw new Error('Application not found');

    if (!app.interviewRounds) app.interviewRounds = [];

    const nextRoundNumber = app.interviewRounds.length + 1;
    const newRound: InterviewRound = {
      ...roundData,
      id: `rnd-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      applicationId: app.id,
      roundNumber: nextRoundNumber,
      status: 'Scheduled',
      mode: (roundData.mode as any) || 'Online (Google Meet)',
      scheduledBy: (roundData as any).scheduledBy || 'recruiter',
      updatedAt: new Date().toISOString()
    };

    app.interviewRounds.push(newRound);
    app.status = 'Interview Scheduled';

    this.persist();
    this.notify('applications', app);

    this.createNotification({
      targetUserId: app.studentId,
      title: `Interview Scheduled: ${newRound.roundName}`,
      message: `${app.company} scheduled ${newRound.roundName} for ${new Date(newRound.dateTime).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })} (${newRound.mode}).`,
      type: 'interview',
      relatedRecordId: newRound.id,
      link: '/interviews'
    });

    return newRound;
  }

  rescheduleInterviewRound(
    applicationId: string,
    roundId: string,
    update: {
      dateTime: string;
      mode?: string;
      meetingLinkOrVenue: string;
      interviewer?: string;
    }
  ): InterviewRound {
    const app = this.data.applications.find(a => a.id === applicationId);
    if (!app) throw new Error('Application not found');

    const round = app.interviewRounds.find(r => r.id === roundId);
    if (!round) throw new Error('Interview round not found');

    round.dateTime = update.dateTime;
    if (update.mode) round.mode = update.mode as any;
    round.meetingLinkOrVenue = update.meetingLinkOrVenue;
    if (update.interviewer) round.interviewer = update.interviewer;
    round.status = 'Rescheduled';
    round.updatedAt = new Date().toISOString();

    this.persist();
    this.notify('applications', app);

    this.createNotification({
      targetUserId: app.studentId,
      title: `Interview Rescheduled: ${round.roundName}`,
      message: `Your interview for ${app.jobTitle} at ${app.company} has been rescheduled to ${new Date(round.dateTime).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}.`,
      type: 'interview',
      relatedRecordId: round.id,
      link: '/interviews'
    });

    return round;
  }

  cancelInterviewRound(
    applicationId: string,
    roundId: string,
    reason?: string
  ): InterviewRound {
    const app = this.data.applications.find(a => a.id === applicationId);
    if (!app) throw new Error('Application not found');

    const round = app.interviewRounds.find(r => r.id === roundId);
    if (!round) throw new Error('Interview round not found');

    round.status = 'On Hold';
    round.feedback = `Cancelled / Put on Hold: ${reason || 'Scheduled slot cancelled by recruiter'}`;
    round.updatedAt = new Date().toISOString();

    this.persist();
    this.notify('applications', app);

    this.createNotification({
      targetUserId: app.studentId,
      title: `Interview Cancelled / Put on Hold: ${round.roundName}`,
      message: `Your interview for ${app.jobTitle} at ${app.company} (${round.roundName}) has been placed on hold. Reason: ${reason || 'Slot cancelled by recruiter.'}`,
      type: 'interview',
      relatedRecordId: round.id,
      link: '/interviews'
    });

    return round;
  }

  rejectInterviewRound(
    applicationId: string,
    roundId: string,
    category: RejectionCategory,
    feedback: string,
    recruiterId?: string
  ): InterviewRound {
    const app = this.data.applications.find(a => a.id === applicationId);
    if (!app) throw new Error('Application not found');

    const round = app.interviewRounds.find(r => r.id === roundId);
    if (!round) throw new Error('Interview round not found');

    const roundRejection: RejectionFeedback = {
      id: `rej-rnd-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      category,
      feedback: feedback.trim(),
      recruiterId: recruiterId || 'rec-01',
      recruiterName: 'Recruiter',
      companyName: app.company,
      rejectedAt: new Date().toISOString(),
      applicationId: app.id,
      interviewRoundId: round.id
    };

    round.status = 'Rejected';
    round.rejectionFeedback = roundRejection;
    round.feedback = feedback.trim();
    round.updatedAt = new Date().toISOString();

    app.status = 'Rejected';
    app.rejectionFeedback = roundRejection;

    this.persist();
    this.notify('applications', app);

    this.createNotification({
      targetUserId: app.studentId,
      title: `Interview Result: ${app.company} (${round.roundName})`,
      message: `Evaluation outcome: Not selected for further rounds. Category: ${category}. Feedback: "${feedback.trim()}".`,
      type: 'interview',
      relatedRecordId: round.id,
      link: '/interviews'
    });

    return round;
  }

  // --- Notifications ---
  getNotifications(userId?: string): AppNotification[] {
    if (!userId) return this.data.notifications;
    return this.data.notifications.filter(n => n.targetUserId === userId);
  }

  createNotification(notif: Omit<AppNotification, 'id' | 'createdAt' | 'read'>): AppNotification {
    const newNotif: AppNotification = {
      ...notif,
      id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      read: false,
      createdAt: new Date().toISOString()
    };
    this.data.notifications.unshift(newNotif);
    this.persist();
    this.notify('notifications', newNotif);
    return newNotif;
  }

  markNotificationAsRead(id: string): void {
    const notif = this.data.notifications.find(n => n.id === id);
    if (notif) {
      notif.read = true;
      this.persist();
      this.notify('notifications', notif);
    }
  }

  // --- Placement Drives & Projects ---
  getPlacementDrives(): PlacementDrive[] {
    return this.data.placementDrives;
  }

  getProjects(): Project[] {
    return this.data.projects;
  }

  getCalendarEvents(): CalendarEvent[] {
    return this.data.calendarEvents;
  }
}

export const campusDb = new CampusDatabase();
