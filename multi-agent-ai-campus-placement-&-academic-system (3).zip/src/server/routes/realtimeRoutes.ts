import { Router, Request, Response } from 'express';
import { campusDb } from '../db';

export const realtimeRouter = Router();

const clients = new Set<Response>();

// Subscribe to database changes and push SSE events
campusDb.subscribe((entity: string, data: any) => {
  const payload = JSON.stringify({ entity, data, timestamp: new Date().toISOString() });
  clients.forEach(client => {
    try {
      client.write(`event: ${entity}\ndata: ${payload}\n\n`);
    } catch (err) {
      clients.delete(client);
    }
  });
});

realtimeRouter.get('/stream', (req: Request, res: Response) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Access-Control-Allow-Origin': '*'
  });

  // Send initial connection event
  res.write(`event: connected\ndata: ${JSON.stringify({ status: 'connected', time: new Date().toISOString() })}\n\n`);

  clients.add(res);

  // Keep-alive heartbeat every 25 seconds
  const heartbeat = setInterval(() => {
    try {
      res.write(': heartbeat\n\n');
    } catch (err) {
      clearInterval(heartbeat);
      clients.delete(res);
    }
  }, 25000);

  req.on('close', () => {
    clearInterval(heartbeat);
    clients.delete(res);
  });
});
