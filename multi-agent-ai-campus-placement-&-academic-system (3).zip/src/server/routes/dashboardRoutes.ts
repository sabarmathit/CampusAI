import { Router, Request, Response } from 'express';
import { campusDb } from '../db';

export const dashboardRouter = Router();

// Student Dashboard Aggregation
dashboardRouter.get('/student', (req: Request, res: Response) => {
  const userId = req.query.userId as string;
  const user = userId ? campusDb.getUserById(userId) : campusDb.getUsers().find(u => u.role === 'student');

  if (!user) {
    res.status(404).json({ error: 'Student profile not found' });
    return;
  }

  const allAttendance = campusDb.getAttendance();
  const studentAttendance = allAttendance.filter(
    a => a.studentId === user.id || (user.rollNo && a.studentRollNo === user.rollNo)
  );

  const totalClasses = studentAttendance.length;
  const totalPresent = studentAttendance.filter(a => a.status === 'present').length;
  const overallAttendance = totalClasses > 0 ? Math.round((totalPresent / totalClasses) * 100) : 100;

  const allAssignments = campusDb.getAssignments();
  const allSubmissions = campusDb.getSubmissions();
  const studentSubmissions = allSubmissions.filter(
    s => s.studentId === user.id || (user.rollNo && s.studentRollNo === user.rollNo)
  );
  const pendingAssignments = allAssignments.filter(
    a => !studentSubmissions.some(s => s.assignmentId === a.id)
  );

  const allApplications = campusDb.getApplications();
  const studentApplications = allApplications.filter(
    a => a.studentId === user.id || (user.rollNo && a.studentRollNo === user.rollNo)
  );

  const allJobs = campusDb.getJobPosts();
  const eligibleOpportunities = allJobs.filter(j => {
    const isCgpaEligible = !j.minCGPA || (user.cgpa || 0) >= j.minCGPA;
    const isDeptEligible = !j.eligibleDepartments || j.eligibleDepartments.some(
      d => d.toLowerCase().includes((user.department || '').toLowerCase())
    );
    return isCgpaEligible && isDeptEligible;
  });

  const activeInterviews = studentApplications.flatMap(a => a.interviewRounds || []).filter(
    r => r.status === 'Scheduled' || r.status === 'Rescheduled' || r.status === 'In Progress'
  );

  res.json({
    studentId: user.id,
    studentName: user.name,
    rollNo: user.rollNo,
    cgpa: user.cgpa || 8.0,
    department: user.department,
    attendance: {
      percentage: overallAttendance,
      totalPresent,
      totalClasses,
      isCompliant: overallAttendance >= 75
    },
    assignments: {
      total: allAssignments.length,
      submitted: studentSubmissions.length,
      pending: pendingAssignments.length
    },
    applications: {
      total: studentApplications.length,
      shortlisted: studentApplications.filter(a => a.status === 'Shortlisted').length,
      selected: studentApplications.filter(a => a.status === 'Selected').length,
      rejected: studentApplications.filter(a => a.status === 'Rejected').length
    },
    interviews: {
      activeRoundsCount: activeInterviews.length
    },
    eligibleOpportunitiesCount: eligibleOpportunities.length,
    recentApplications: studentApplications.slice(0, 5),
    activeInterviews
  });
});

// Faculty Dashboard Aggregation
dashboardRouter.get('/faculty', (req: Request, res: Response) => {
  const userId = req.query.userId as string;
  const user = userId ? campusDb.getUserById(userId) : campusDb.getUsers().find(u => u.role === 'faculty');

  const allStudents = campusDb.getUsers().filter(u => u.role === 'student');
  const allAssignments = campusDb.getAssignments();
  const facultyAssignments = user ? allAssignments.filter(a => a.facultyId === user.id) : allAssignments;
  const allSubmissions = campusDb.getSubmissions();
  const allAttendance = campusDb.getAttendance();

  // Identify attendance shortage (<75%)
  let lowAttendanceCount = 0;
  allStudents.forEach(st => {
    const sAtt = allAttendance.filter(a => a.studentId === st.id);
    const present = sAtt.filter(a => a.status === 'present').length;
    const total = sAtt.length;
    const pct = total > 0 ? (present / total) * 100 : 100;
    if (pct < 75 && total > 0) lowAttendanceCount++;
  });

  const pendingGradingSubmissions = allSubmissions.filter(
    s => s.status === 'submitted' && facultyAssignments.some(a => a.id === s.assignmentId)
  );

  res.json({
    facultyId: user?.id,
    facultyName: user?.name,
    enrolledStudentsCount: allStudents.length,
    activeAssignmentsCount: facultyAssignments.length,
    pendingGradingCount: pendingGradingSubmissions.length,
    attendanceShortageCount: lowAttendanceCount,
    recentSubmissions: pendingGradingSubmissions.slice(0, 5),
    assignmentsSummary: facultyAssignments.map(a => ({
      id: a.id,
      title: a.title,
      subject: a.subject,
      dueDate: a.dueDate,
      submissionCount: allSubmissions.filter(s => s.assignmentId === a.id).length
    }))
  });
});

// Recruiter Dashboard Aggregation
dashboardRouter.get('/recruiter', (req: Request, res: Response) => {
  const userId = req.query.userId as string;
  const user = userId ? campusDb.getUserById(userId) : campusDb.getUsers().find(u => u.role === 'recruiter');

  const company = (user?.companyName || '').toLowerCase().trim();
  const allJobs = campusDb.getJobPosts();
  const myJobs = allJobs.filter(
    j => (user && j.recruiterId === user.id) || (company && j.company.toLowerCase().includes(company))
  );
  const myJobIds = new Set(myJobs.map(j => j.id));

  const allApps = campusDb.getApplications();
  const myApps = myJobIds.size > 0 ? allApps.filter(a => myJobIds.has(a.jobId)) : allApps;

  const activeRounds = myApps.flatMap(a => a.interviewRounds || []).filter(
    r => r.status === 'Scheduled' || r.status === 'In Progress' || r.status === 'Rescheduled'
  );

  res.json({
    recruiterId: user?.id,
    company: user?.companyName,
    activeJobsCount: myJobs.length,
    totalApplicantsCount: myApps.length,
    shortlistedCount: myApps.filter(a => a.status === 'Shortlisted').length,
    interviewingCount: myApps.filter(a => a.status === 'Interview Scheduled' || a.status === 'Interviewing').length,
    selectedOffersCount: myApps.filter(a => a.status === 'Selected').length,
    rejectedCount: myApps.filter(a => a.status === 'Rejected').length,
    scheduledInterviewsCount: activeRounds.length,
    recentApplicants: myApps.slice(0, 5),
    upcomingInterviews: activeRounds.slice(0, 5)
  });
});

// Placement Cell Dashboard Aggregation
dashboardRouter.get('/placement', (req: Request, res: Response) => {
  const allStudents = campusDb.getUsers().filter(u => u.role === 'student');
  const allJobs = campusDb.getJobPosts();
  const allApps = campusDb.getApplications();
  const selectedApps = allApps.filter(a => a.status === 'Selected');
  const placedStudentIds = new Set(selectedApps.map(a => a.studentId));

  const placementRate = allStudents.length > 0 
    ? Math.round((placedStudentIds.size / allStudents.length) * 100) 
    : 0;

  // Companies offering roles
  const activeCompanies = Array.from(new Set(allJobs.map(j => j.company)));

  // Scheduled rounds
  const totalInterviews = allApps.flatMap(a => a.interviewRounds || []).length;

  res.json({
    totalStudentsRegistered: allStudents.length,
    placedStudentsCount: placedStudentIds.size,
    overallPlacementRate: placementRate,
    totalJobPostings: allJobs.length,
    participatingCompaniesCount: activeCompanies.length,
    totalApplicationsProcessed: allApps.length,
    totalInterviewsConducted: totalInterviews,
    offersIssued: selectedApps.length,
    companies: activeCompanies.slice(0, 8),
    recentApplications: allApps.slice(0, 5)
  });
});
