import { Router, Request, Response } from 'express';
import { campusDb } from '../db';
import { MultiAgentOrchestrator, ChatHistoryMessage } from '../agents/multiAgentOrchestrator';

export const aiRouter = Router();

aiRouter.post('/chat', async (req: Request, res: Response) => {
  try {
    const { userId, role, query, history } = req.body;

    if (!query || typeof query !== 'string') {
      res.status(400).json({ error: 'Query string is required' });
      return;
    }

    // Authenticate user
    let user = userId ? campusDb.getUserById(userId) : undefined;
    if (!user && role) {
      user = campusDb.getUsers().find(u => u.role === role);
    }
    if (!user) {
      // Default fallback student user
      user = campusDb.getUsers().find(u => u.role === 'student') || campusDb.getUsers()[0];
    }

    const chatHistory: ChatHistoryMessage[] = Array.isArray(history) ? history : [];
    const result = await MultiAgentOrchestrator.processQuery(user, query, chatHistory);

    res.json({
      success: true,
      answer: result.text,
      agentId: result.agentId,
      retrievedEntities: result.retrievedEntities,
      ragUsed: result.ragUsed
    });
  } catch (err: any) {
    console.error('Error handling AI chat request:', err);
    res.status(500).json({
      error: 'Failed to process AI chat query',
      details: err.message
    });
  }
});
