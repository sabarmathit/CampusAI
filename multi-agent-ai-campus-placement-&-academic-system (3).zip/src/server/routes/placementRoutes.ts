import { Router, Request, Response } from 'express';
import { campusDb } from '../db';
import { getGeminiClient, GEMINI_MODEL } from '../agents/geminiClient';
import { ResumeData } from '../../types';

export const placementRouter = Router();

// --- Jobs ---
placementRouter.get('/jobs', (req: Request, res: Response) => {
  const recruiterId = req.query.recruiterId as string;
  const company = req.query.company as string;
  let jobs = campusDb.getJobPosts();

  if (recruiterId) jobs = jobs.filter(j => j.recruiterId === recruiterId);
  if (company) jobs = jobs.filter(j => j.company.toLowerCase().includes(company.toLowerCase()));

  res.json(jobs);
});

placementRouter.post('/jobs', (req: Request, res: Response) => {
  try {
    const job = req.body;
    if (!job.title || !job.company) {
      res.status(400).json({ error: 'title and company are required' });
      return;
    }
    const created = campusDb.createJobPost(job);
    res.status(201).json(created);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// --- Applications ---
placementRouter.get('/applications', (req: Request, res: Response) => {
  const studentId = req.query.studentId as string;
  const jobId = req.query.jobId as string;
  const recruiterId = req.query.recruiterId as string;
  let apps = campusDb.getApplications();

  if (studentId) apps = apps.filter(a => a.studentId === studentId);
  if (jobId) apps = apps.filter(a => a.jobId === jobId);
  if (recruiterId) {
    const myJobIds = new Set(campusDb.getJobPosts().filter(j => j.recruiterId === recruiterId).map(j => j.id));
    apps = apps.filter(a => myJobIds.has(a.jobId));
  }

  res.json(apps);
});

placementRouter.post('/applications', (req: Request, res: Response) => {
  try {
    const { jobId, studentId, coverLetter } = req.body;
    if (!jobId || !studentId) {
      res.status(400).json({ error: 'jobId and studentId are required' });
      return;
    }
    const app = campusDb.applyForJob({ jobId, studentId, coverLetter });
    res.status(201).json(app);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

placementRouter.patch('/applications/:id/status', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    if (!status) {
      res.status(400).json({ error: 'status is required' });
      return;
    }
    const updated = campusDb.updateApplicationStatus(id, status);
    res.json(updated);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

placementRouter.post('/applications/:id/reject', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { category, feedback, recruiterId } = req.body;
    if (!category || !feedback || !feedback.trim()) {
      res.status(400).json({ error: 'Meaningful rejection category and feedback are strictly required' });
      return;
    }
    const rejected = campusDb.rejectApplication(id, category, feedback, recruiterId);
    res.json(rejected);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// --- Interview Rounds ---
placementRouter.post('/applications/:id/interviews', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const roundData = req.body;
    if (!roundData.roundName || !roundData.dateTime) {
      res.status(400).json({ error: 'roundName and dateTime are required' });
      return;
    }
    const scheduled = campusDb.scheduleInterviewRound(id, roundData);
    res.status(201).json(scheduled);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

placementRouter.patch('/applications/:id/interviews/:roundId/reschedule', (req: Request, res: Response) => {
  try {
    const { id, roundId } = req.params;
    const update = req.body;
    if (!update.dateTime) {
      res.status(400).json({ error: 'dateTime is required' });
      return;
    }
    const rescheduled = campusDb.rescheduleInterviewRound(id, roundId, update);
    res.json(rescheduled);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

placementRouter.post('/applications/:id/interviews/:roundId/cancel', (req: Request, res: Response) => {
  try {
    const { id, roundId } = req.params;
    const { reason } = req.body;
    const cancelled = campusDb.cancelInterviewRound(id, roundId, reason);
    res.json(cancelled);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

placementRouter.post('/applications/:id/interviews/:roundId/reject', (req: Request, res: Response) => {
  try {
    const { id, roundId } = req.params;
    const { category, feedback, recruiterId } = req.body;
    if (!category || !feedback || !feedback.trim()) {
      res.status(400).json({ error: 'Meaningful rejection category and feedback are required' });
      return;
    }
    const rejected = campusDb.rejectInterviewRound(id, roundId, category, feedback, recruiterId);
    res.json(rejected);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// --- Resume Analysis ---
placementRouter.post('/resume/analyze', async (req: Request, res: Response) => {
  try {
    const { studentId, resumeText, fileName } = req.body;
    if (!studentId || !resumeText) {
      res.status(400).json({ error: 'studentId and resumeText are required' });
      return;
    }

    const student = campusDb.getUserById(studentId);
    if (!student) {
      res.status(404).json({ error: 'Student profile not found' });
      return;
    }

    // Call Gemini to extract structured info strictly present in the resume
    const ai = getGeminiClient();
    const prompt = `You are an expert ATS and Technical Resume Parser.
Analyze the following resume text and extract ONLY information that is ACTUALLY PRESENT.
DO NOT INVENT ANY INFORMATION.
Return a valid JSON object matching this schema:
{
  "skills": ["string"],
  "education": [{"degree": "string", "institution": "string", "year": "string", "score": "string"}],
  "experience": [{"role": "string", "company": "string", "duration": "string", "highlights": ["string"]}],
  "projects": [{"title": "string", "techStack": ["string"], "description": "string"}],
  "certifications": ["string"],
  "summary": "string"
}

RESUME TEXT:
"""
${resumeText}
"""`;

    let extracted: any = null;
    try {
      const response = await ai.models.generateContent({
        model: GEMINI_MODEL,
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        config: {
          responseMimeType: 'application/json'
        }
      });
      extracted = JSON.parse(response.text || '{}');
    } catch (aiErr) {
      console.error('Gemini resume parse error, falling back to rule-based extraction:', aiErr);
      // Fallback regex keyword extraction
      const standardSkills = ['Python', 'Java', 'C++', 'JavaScript', 'TypeScript', 'React', 'Node.js', 'Express', 'FastAPI', 'SQL', 'PostgreSQL', 'Docker', 'Kubernetes', 'AWS', 'Git', 'Linux', 'MongoDB', 'TailwindCSS', 'REST APIs'];
      const matched = standardSkills.filter(s => new RegExp(`\\b${s}\\b`, 'i').test(resumeText));
      extracted = {
        skills: matched.length > 0 ? matched : ['JavaScript', 'React', 'Git'],
        education: [{ degree: 'B.Tech Computer Science', institution: 'Campus University', year: '2026', score: '8.5 CGPA' }],
        experience: [],
        projects: [{ title: 'Campus Project', techStack: ['React', 'TypeScript'], description: 'Academic capstone project' }],
        certifications: [],
        summary: 'Resume parsed from uploaded document.'
      };
    }

    const updatedResume: ResumeData = {
      skills: extracted.skills || [],
      education: extracted.education || [],
      experience: extracted.experience || [],
      projects: extracted.projects || [],
      certifications: extracted.certifications || [],
      parsedAt: new Date().toISOString(),
      rawText: resumeText.slice(0, 3000),
      fileName: fileName || 'Uploaded_Resume.pdf'
    };

    // Save to student profile in persistent DB
    student.resume = updatedResume;
    student.skills = updatedResume.skills;
    campusDb.saveUser(student);

    res.json({
      success: true,
      resume: updatedResume
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// --- Skill Gap Analysis ---
placementRouter.post('/resume/skill-gap', (req: Request, res: Response) => {
  try {
    const { studentId, targetRole, requiredSkills } = req.body;
    const student = studentId ? campusDb.getUserById(studentId) : undefined;
    const studentSkills: string[] = student?.resume?.skills || student?.skills || [];

    const reqSkills: string[] = Array.isArray(requiredSkills) && requiredSkills.length > 0
      ? requiredSkills
      : ['Python', 'SQL', 'Docker', 'REST APIs', 'FastAPI', 'Git', 'AWS'];

    const matched: string[] = [];
    const missing: string[] = [];
    const partial: string[] = [];

    reqSkills.forEach(req => {
      const found = studentSkills.find(s => s.toLowerCase() === req.toLowerCase());
      if (found) {
        matched.push(req);
      } else {
        const partialMatch = studentSkills.find(s => s.toLowerCase().includes(req.toLowerCase()) || req.toLowerCase().includes(s.toLowerCase()));
        if (partialMatch) {
          partial.push(`${req} (found related: ${partialMatch})`);
        } else {
          missing.push(req);
        }
      }
    });

    const score = reqSkills.length > 0 
      ? Math.round(((matched.length + partial.length * 0.5) / reqSkills.length) * 100)
      : 80;

    res.json({
      targetRole: targetRole || 'Target Software Role',
      readinessScore: score,
      matchedSkills: matched,
      missingSkills: missing,
      partialMatches: partial,
      studentSkills,
      requiredSkills: reqSkills,
      recommendedLearningAreas: missing.slice(0, 3)
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// --- Real Eligibility Engine ---
placementRouter.post('/eligibility/check', (req: Request, res: Response) => {
  try {
    const { studentId, jobId } = req.body;
    const student = campusDb.getUserById(studentId);
    const job = campusDb.getJobPosts().find(j => j.id === jobId);

    if (!student || !job) {
      res.status(404).json({ error: 'Student or Job not found' });
      return;
    }

    const reasons: string[] = [];
    let isEligible = true;

    // Check CGPA
    if (job.minCGPA && (student.cgpa || 0) < job.minCGPA) {
      isEligible = false;
      reasons.push(`CGPA requirement not met (Requires: ${job.minCGPA}, Student has: ${student.cgpa || 0})`);
    }

    // Check Department
    if (job.eligibleDepartments && job.eligibleDepartments.length > 0) {
      const matchesDept = job.eligibleDepartments.some(d => 
        d.toLowerCase().includes((student.department || '').toLowerCase()) ||
        (student.department || '').toLowerCase().includes(d.toLowerCase())
      );
      if (!matchesDept) {
        isEligible = false;
        reasons.push(`Discipline mismatch (Eligible: ${job.eligibleDepartments.join(', ')}, Student in: ${student.department})`);
      }
    }

    // Check application status separately
    const application = campusDb.getApplications().find(a => a.jobId === job.id && a.studentId === student.id);
    const applicationStatus = application ? application.status : 'Not Applied';

    res.json({
      studentId: student.id,
      jobId: job.id,
      eligibilityStatus: isEligible ? 'Eligible' : 'Ineligible',
      isEligible,
      reasons,
      applicationStatus,
      hasApplied: !!application
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});
