import { Router, Request, Response } from 'express';
import { campusDb } from '../db';

export const academicRouter = Router();

// --- Attendance ---
academicRouter.get('/attendance', (req: Request, res: Response) => {
  const studentId = req.query.studentId as string;
  const subject = req.query.subject as string;
  let records = campusDb.getAttendance();

  if (studentId) {
    records = records.filter(r => r.studentId === studentId);
  }
  if (subject) {
    records = records.filter(r => r.subject.toLowerCase().includes(subject.toLowerCase()));
  }

  res.json(records);
});

academicRouter.post('/attendance/batch', (req: Request, res: Response) => {
  try {
    const { records } = req.body;
    if (!Array.isArray(records)) {
      res.status(400).json({ error: 'Records array required' });
      return;
    }

    const saved = campusDb.saveAttendanceBatch(records);
    res.json({ success: true, count: saved.length, records: saved });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// --- Assignments ---
academicRouter.get('/assignments', (req: Request, res: Response) => {
  const facultyId = req.query.facultyId as string;
  const assignments = campusDb.getAssignments();
  if (facultyId) {
    res.json(assignments.filter(a => a.facultyId === facultyId));
    return;
  }
  res.json(assignments);
});

academicRouter.post('/assignments', (req: Request, res: Response) => {
  try {
    const asg = req.body;
    if (!asg.title || !asg.subject || !asg.dueDate) {
      res.status(400).json({ error: 'title, subject, and dueDate required' });
      return;
    }
    const created = campusDb.createAssignment(asg);
    res.status(201).json(created);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// --- Submissions ---
academicRouter.get('/submissions', (req: Request, res: Response) => {
  const assignmentId = req.query.assignmentId as string;
  const studentId = req.query.studentId as string;
  let subs = campusDb.getSubmissions();

  if (assignmentId) subs = subs.filter(s => s.assignmentId === assignmentId);
  if (studentId) subs = subs.filter(s => s.studentId === studentId);

  res.json(subs);
});

academicRouter.post('/submissions', (req: Request, res: Response) => {
  try {
    const sub = req.body;
    if (!sub.assignmentId || !sub.studentId) {
      res.status(400).json({ error: 'assignmentId and studentId are required' });
      return;
    }
    const saved = campusDb.saveSubmission(sub);
    res.status(201).json(saved);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

academicRouter.post('/submissions/:id/grade', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { marksObtained, feedback } = req.body;
    if (typeof marksObtained !== 'number') {
      res.status(400).json({ error: 'marksObtained number required' });
      return;
    }
    const graded = campusDb.gradeSubmission(id, marksObtained, feedback);
    res.json(graded);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// --- Marks ---
academicRouter.get('/marks/internal', (req: Request, res: Response) => {
  const studentId = req.query.studentId as string;
  const marks = campusDb.getInternalMarks();
  if (studentId) {
    res.json(marks.filter(m => m.studentId === studentId));
    return;
  }
  res.json(marks);
});

academicRouter.get('/marks/semester', (req: Request, res: Response) => {
  const studentId = req.query.studentId as string;
  const marks = campusDb.getSemesterMarks();
  if (studentId) {
    res.json(marks.filter(m => m.studentId === studentId));
    return;
  }
  res.json(marks);
});
