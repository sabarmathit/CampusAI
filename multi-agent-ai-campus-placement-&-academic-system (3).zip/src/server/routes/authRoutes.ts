import { Router, Request, Response } from 'express';
import { campusDb } from '../db';

export const authRouter = Router();

authRouter.get('/users', (req: Request, res: Response) => {
  const role = req.query.role as string;
  let users = campusDb.getUsers();
  if (role) users = users.filter(u => u.role === role);
  res.json(users);
});

authRouter.get('/users/:id', (req: Request, res: Response) => {
  const user = campusDb.getUserById(req.params.id);
  if (!user) {
    res.status(404).json({ error: 'User not found' });
    return;
  }
  res.json(user);
});

authRouter.post('/users', (req: Request, res: Response) => {
  try {
    const user = req.body;
    if (!user.id || !user.email) {
      res.status(400).json({ error: 'id and email are required' });
      return;
    }
    const saved = campusDb.saveUser(user);
    res.json(saved);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

authRouter.get('/notifications', (req: Request, res: Response) => {
  const userId = req.query.userId as string;
  const notifs = campusDb.getNotifications(userId);
  res.json(notifs);
});

authRouter.post('/notifications/:id/read', (req: Request, res: Response) => {
  try {
    campusDb.markNotificationAsRead(req.params.id);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});
