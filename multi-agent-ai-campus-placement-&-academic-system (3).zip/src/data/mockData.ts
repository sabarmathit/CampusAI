import { 
  User, 
  Subject,
  Assignment, 
  Submission, 
  AttendanceRecord, 
  InternalMarkRecord,
  SemesterMarkRecord,
  JobPost, 
  Application, 
  PlacementDrive,
  Project, 
  AppNotification, 
  CalendarEvent, 
  AIAgent 
} from '../types';

export const INITIAL_USERS: User[] = [
  {
    id: 'stu-01',
    name: 'Sabarmathi T',
    email: 'sabarmathit@campus.edu',
    password: 'password123',
    role: 'student',
    profileCompleted: true,
    registerNumber: '21CS104',
    rollNo: '21CS104',
    phone: '+91 98401 23456',
    dateOfBirth: '2004-05-14',
    gender: 'Female',
    address: '74 Campus Avenue, Technology Park, Bengaluru, Karnataka - 560100',
    linkedIn: 'https://linkedin.com/in/sabarmathi-t',
    github: 'https://github.com/sabarmathit',
    portfolioUrl: 'https://sabarmathi.dev',
    bio: 'Final year CSE undergraduate passionate about distributed systems, autonomous multi-agent AI, and modern web engineering.',
    collegeName: 'National Institute of Engineering & Technology',
    department: 'Computer Science & Engineering',
    degree: 'Bachelor of Engineering (B.E.)',
    currentYear: 4,
    currentSemester: 8,
    graduationYear: 2026,
    cgpa: 8.92,
    backlogStatus: 'No Backlogs',
    activeBacklogs: 0,
    skills: ['React', 'TypeScript', 'Node.js', 'Python', 'FastAPI', 'Docker', 'PostgreSQL', 'Machine Learning'],
    extracurriculars: [
      {
        id: 'ec-01',
        title: 'Lead Organizer - Smart Campus Hackathon 2025',
        category: 'Hackathon',
        description: 'Spearheaded 36-hour inter-collegiate hackathon with 600+ participants and sponsored cloud tracks.',
        date: '2025-11-12'
      },
      {
        id: 'ec-02',
        title: 'President - Open Source & AI Developers Club',
        category: 'Leadership',
        description: 'Mentored 120+ junior students on Git workflows, TypeScript microservices, and LLM orchestration.',
        date: '2025-08-20'
      },
      {
        id: 'ec-03',
        title: 'AWS Certified Cloud Practitioner',
        category: 'Certification',
        description: 'Validated foundational knowledge of AWS cloud compute, storage, security, and VPC network architectures.',
        date: '2025-06-15'
      }
    ],
    resume: {
      fileName: 'Sabarmathi_T_Resume_2026.pdf',
      fileSize: 245000,
      fileType: 'application/pdf',
      uploadedAt: '2026-09-15T10:00:00Z',
      extractedSkills: ['React', 'TypeScript', 'Node.js', 'Python', 'FastAPI', 'Docker', 'PostgreSQL', 'Machine Learning', 'Git', 'Tailwind CSS', 'SQL', 'REST APIs'],
      programmingLanguages: ['TypeScript', 'JavaScript', 'Python', 'C++', 'SQL'],
      frameworksTools: ['React', 'Next.js', 'FastAPI', 'Node.js', 'Docker', 'PostgreSQL', 'Git', 'Tailwind CSS'],
      projects: [
        {
          title: 'Distributed Consensus & Raft Cluster Simulator',
          description: 'Implemented Raft consensus algorithm with leader election, log replication, and heartbeat fault recovery in TypeScript and Python.',
          techStack: ['TypeScript', 'Node.js', 'Distributed Systems'],
          role: 'Lead Developer'
        },
        {
          title: 'AI Multi-Agent Campus Workflow Orchestrator',
          description: 'Constructed asynchronous multi-agent coordination pipeline leveraging FastAPI, vector indices, and PostgreSQL state persistence.',
          techStack: ['Python', 'FastAPI', 'PostgreSQL', 'Docker'],
          role: 'Architect'
        }
      ],
      experience: [
        {
          company: 'CloudMatrix Innovations',
          role: 'Full-Stack Software Engineering Intern',
          duration: 'May 2025 - Jul 2025',
          description: 'Engineered performant React 19 dashboards and optimized PostgreSQL join queries, reducing latency by 38%.'
        }
      ],
      certifications: [
        'AWS Certified Cloud Practitioner (CLF-C02)',
        'Meta Front-End Developer Professional Certificate'
      ],
      education: [
        {
          degree: 'B.E. Computer Science & Engineering',
          institution: 'National Institute of Engineering & Technology',
          year: '2022 - 2026',
          score: 'CGPA 8.92'
        }
      ],
      achievements: [
        'Top 10 Finalist in National Smart India Hackathon',
        'Solved 450+ LeetCode DSA Problems (Top 5% Rating)'
      ],
      targetRole: 'Full Stack Developer'
    }
  },
  {
    id: 'stu-02',
    name: 'Rahul Verma',
    email: 'rahul.verma@campus.edu',
    password: 'password123',
    role: 'student',
    rollNo: '21CS118',
    department: 'Computer Science & Engineering',
    graduationYear: 2026,
    cgpa: 7.45,
    skills: ['Java', 'Spring Boot', 'MySQL', 'Git', 'HTML', 'CSS', 'AWS Basics'],
    phone: '+91 98402 34567',
    bio: 'Aspiring backend engineer focusing on microservices, enterprise Java architecture, and clean API design.',
    resume: {
      fileName: 'Rahul_Verma_CV.pdf',
      fileSize: 180000,
      fileType: 'application/pdf',
      uploadedAt: '2026-09-18T12:00:00Z',
      extractedSkills: ['Java', 'Spring Boot', 'MySQL', 'Git', 'AWS Basics', 'REST APIs'],
      targetRole: 'Backend Developer'
    }
  },
  {
    id: 'stu-03',
    name: 'Ananya Iyer',
    email: 'ananya.iyer@campus.edu',
    password: 'password123',
    role: 'student',
    rollNo: '21IT045',
    department: 'Information Technology',
    graduationYear: 2026,
    cgpa: 9.15,
    skills: ['Python', 'TensorFlow', 'PyTorch', 'SQL', 'FastAPI', 'Data Analytics', 'Computer Vision'],
    phone: '+91 98403 45678',
    bio: 'AI/ML enthusiast working on multimodal neural models and automated campus vision analytics.',
    resume: {
      fileName: 'Ananya_Iyer_AI_Research.pdf',
      fileSize: 310000,
      fileType: 'application/pdf',
      uploadedAt: '2026-09-20T09:30:00Z',
      extractedSkills: ['Python', 'TensorFlow', 'PyTorch', 'SQL', 'FastAPI', 'Data Analytics', 'Pandas'],
      targetRole: 'AI/ML Engineer'
    }
  },
  {
    id: 'stu-04',
    name: 'Karthik Raman',
    email: 'karthik.raman@campus.edu',
    password: 'password123',
    role: 'student',
    rollNo: '21EC082',
    department: 'Electronics & Communication',
    graduationYear: 2026,
    cgpa: 8.10,
    skills: ['Embedded C', 'IoT', 'Python', 'Verilog', 'Microcontrollers', 'C++'],
    phone: '+91 98404 56789',
    bio: 'Hardware-software co-design explorer building connected IoT sensing nodes for smart campus management.'
  },
  {
    id: 'stu-05',
    name: 'Sneha Patel',
    email: 'sneha.patel@campus.edu',
    password: 'password123',
    role: 'student',
    rollNo: '21CS134',
    department: 'Computer Science & Engineering',
    graduationYear: 2026,
    cgpa: 6.80,
    skills: ['HTML', 'CSS', 'JavaScript', 'Python', 'Figma', 'UI/UX Design'],
    phone: '+91 98405 67890',
    bio: 'Creative frontend developer with strong design intuition and practical component architecture skills.'
  },
  {
    id: 'fac-01',
    name: 'Dr. Sundar Rajan',
    email: 'sundar.rajan@campus.edu',
    password: 'password123',
    role: 'faculty',
    department: 'Computer Science & Engineering',
    designation: 'Professor & Academic Course Director',
    specialization: 'Distributed Systems & Cloud Computing',
    phone: '+91 94440 12345',
    bio: '20+ years in distributed systems, curriculum design, and supervising final-year capstone engineering projects.'
  },
  {
    id: 'fac-02',
    name: 'Prof. Meenakshi Sundaram',
    email: 'meenakshi.s@campus.edu',
    password: 'password123',
    role: 'faculty',
    department: 'Computer Science & Engineering',
    designation: 'Associate Professor & Lab Coordinator',
    specialization: 'Advanced Database Systems & Microservices',
    phone: '+91 94440 54321',
    bio: 'Specialist in cloud computing, database optimization, and academic laboratory evaluation.'
  },
  {
    id: 'tpo-01',
    name: 'Dr. Vikram Malhotra',
    email: 'placement.cell@campus.edu',
    password: 'password123',
    role: 'placement',
    department: 'Training & Placement Directorate',
    designation: 'Head, Placement & Corporate Relations',
    officeLocation: 'Placement Block, Level 3',
    phone: '+91 98200 99887',
    bio: 'Leading industry partnerships, placement drives, recruiter coordination, and career readiness training.'
  },
  {
    id: 'rec-01',
    name: 'Priya Menon',
    email: 'priya.menon@nexatech.io',
    password: 'password123',
    role: 'recruiter',
    companyName: 'NexaTech Systems',
    designation: 'Lead University Talent Partner',
    phone: '+91 99123 45678',
    bio: 'Connecting exceptional final-year software engineering talent with high-impact product engineering roles.'
  },
  {
    id: 'rec-02',
    name: 'David Chen',
    email: 'david.chen@cloudscale.com',
    password: 'password123',
    role: 'recruiter',
    companyName: 'CloudScale Global',
    designation: 'Campus Hiring Director',
    phone: '+91 99234 56789',
    bio: 'Building next-generation cloud infrastructure teams across top university talent pools.'
  }
];

export const INITIAL_SUBJECTS: Subject[] = [
  {
    id: 'subj-cs801',
    code: 'CS801',
    name: 'Distributed Systems',
    department: 'Computer Science & Engineering',
    credits: 4,
    facultyId: 'fac-01',
    facultyName: 'Dr. Sundar Rajan',
    schedule: 'Mon, Wed 10:00 AM'
  },
  {
    id: 'subj-cs802',
    code: 'CS802',
    name: 'Advanced Database Systems',
    department: 'Computer Science & Engineering',
    credits: 4,
    facultyId: 'fac-01',
    facultyName: 'Dr. Sundar Rajan',
    schedule: 'Tue, Thu 11:30 AM'
  },
  {
    id: 'subj-cs803',
    code: 'CS803',
    name: 'Cloud Computing & DevOps',
    department: 'Computer Science & Engineering',
    credits: 3,
    facultyId: 'fac-02',
    facultyName: 'Prof. Meenakshi Sundaram',
    schedule: 'Wed, Fri 02:00 PM'
  },
  {
    id: 'subj-cs804',
    code: 'CS804',
    name: 'Software Project Management',
    department: 'Computer Science & Engineering',
    credits: 3,
    facultyId: 'fac-02',
    facultyName: 'Prof. Meenakshi Sundaram',
    schedule: 'Mon, Thu 03:30 PM'
  }
];

export const INITIAL_ASSIGNMENTS: Assignment[] = [
  {
    id: 'asg-01',
    title: 'Distributed Consensus & Raft Protocol Simulation',
    subjectId: 'subj-cs801',
    subject: 'Distributed Systems (CS801)',
    department: 'Computer Science & Engineering',
    description: 'Implement a minimal Raft consensus cluster in Python or TypeScript with leader election, log replication, and heartbeat verification. Submit your architecture report and code repository.',
    assignedClass: 'CSE 4th Year - Section A & B',
    dueDate: '2026-10-18',
    dueTime: '23:59',
    maxMarks: 50,
    facultyId: 'fac-01',
    facultyName: 'Dr. Sundar Rajan',
    attachmentName: 'Raft_Specification_v2.pdf',
    allowLateSubmission: false,
    createdAt: '2026-09-28'
  },
  {
    id: 'asg-02',
    title: 'PostgreSQL Query Optimization & Index Benchmarking',
    subjectId: 'subj-cs802',
    subject: 'Advanced Database Systems (CS802)',
    department: 'Computer Science & Engineering',
    description: 'Analyze execution plans for 10M record join queries using EXPLAIN ANALYZE. Benchmark B-Tree vs BRIN indexes and submit your performance telemetry writeup.',
    assignedClass: 'CSE 4th Year',
    dueDate: '2026-10-24',
    dueTime: '17:00',
    maxMarks: 40,
    facultyId: 'fac-01',
    facultyName: 'Dr. Sundar Rajan',
    attachmentName: 'Db_Schema_Dataset.sql',
    allowLateSubmission: true,
    createdAt: '2026-10-01'
  },
  {
    id: 'asg-03',
    title: 'Cloud Native Microservices Deployment with Docker & K8s',
    subjectId: 'subj-cs803',
    subject: 'Cloud Computing & DevOps (CS803)',
    department: 'Computer Science & Engineering',
    description: 'Containerize a 3-tier polyglot service and craft Kubernetes deployment manifests with horizontal pod autoscaling and ingress controllers.',
    assignedClass: 'CSE 4th Year',
    dueDate: '2026-10-30',
    dueTime: '23:59',
    maxMarks: 50,
    facultyId: 'fac-02',
    facultyName: 'Prof. Meenakshi Sundaram',
    allowLateSubmission: false,
    createdAt: '2026-10-01'
  }
];

export const INITIAL_SUBMISSIONS: Submission[] = [
  {
    id: 'sub-01',
    assignmentId: 'asg-01',
    studentId: 'stu-01',
    studentName: 'Sabarmathi T',
    studentRollNo: '21CS104',
    submittedAt: '2026-10-01T14:30:00Z',
    fileName: 'Sabarmathi_Raft_Consensus_Lab.pdf',
    notes: 'Completed leader election, randomized term elections, and heartbeat timeouts with comprehensive test cases in TypeScript.',
    marksObtained: 48,
    feedback: 'Excellent breakdown of partition handling and term increment verification. Clean code documentation.',
    gradedAt: '2026-10-02T09:15:00Z',
    status: 'graded'
  },
  {
    id: 'sub-02',
    assignmentId: 'asg-01',
    studentId: 'stu-02',
    studentName: 'Rahul Verma',
    studentRollNo: '21CS118',
    submittedAt: '2026-10-03T11:20:00Z',
    fileName: 'RahulVerma_Raft_Report.zip',
    notes: 'Implemented leader election using Java socket programming. Log replication edge cases included.',
    marksObtained: undefined,
    feedback: undefined,
    status: 'submitted'
  }
];

export const INITIAL_ATTENDANCE: AttendanceRecord[] = [
  // Subject 1: Distributed Systems (CS801) - Sabarmathi
  { id: 'att-01', studentId: 'stu-01', studentName: 'Sabarmathi T', studentRollNo: '21CS104', department: 'Computer Science & Engineering', subjectId: 'subj-cs801', subject: 'Distributed Systems (CS801)', date: '2026-09-25', status: 'present', facultyId: 'fac-01', facultyName: 'Dr. Sundar Rajan' },
  { id: 'att-02', studentId: 'stu-01', studentName: 'Sabarmathi T', studentRollNo: '21CS104', department: 'Computer Science & Engineering', subjectId: 'subj-cs801', subject: 'Distributed Systems (CS801)', date: '2026-09-26', status: 'present', facultyId: 'fac-01', facultyName: 'Dr. Sundar Rajan' },
  { id: 'att-03', studentId: 'stu-01', studentName: 'Sabarmathi T', studentRollNo: '21CS104', department: 'Computer Science & Engineering', subjectId: 'subj-cs801', subject: 'Distributed Systems (CS801)', date: '2026-09-28', status: 'present', facultyId: 'fac-01', facultyName: 'Dr. Sundar Rajan' },
  { id: 'att-04', studentId: 'stu-01', studentName: 'Sabarmathi T', studentRollNo: '21CS104', department: 'Computer Science & Engineering', subjectId: 'subj-cs801', subject: 'Distributed Systems (CS801)', date: '2026-09-29', status: 'present', facultyId: 'fac-01', facultyName: 'Dr. Sundar Rajan' },
  { id: 'att-05', studentId: 'stu-01', studentName: 'Sabarmathi T', studentRollNo: '21CS104', department: 'Computer Science & Engineering', subjectId: 'subj-cs801', subject: 'Distributed Systems (CS801)', date: '2026-10-01', status: 'present', facultyId: 'fac-01', facultyName: 'Dr. Sundar Rajan' },

  // Subject 2: Advanced Database Systems (CS802) - Sabarmathi
  { id: 'att-06', studentId: 'stu-01', studentName: 'Sabarmathi T', studentRollNo: '21CS104', department: 'Computer Science & Engineering', subjectId: 'subj-cs802', subject: 'Advanced Database Systems (CS802)', date: '2026-09-25', status: 'present', facultyId: 'fac-01', facultyName: 'Dr. Sundar Rajan' },
  { id: 'att-07', studentId: 'stu-01', studentName: 'Sabarmathi T', studentRollNo: '21CS104', department: 'Computer Science & Engineering', subjectId: 'subj-cs802', subject: 'Advanced Database Systems (CS802)', date: '2026-09-27', status: 'present', facultyId: 'fac-01', facultyName: 'Dr. Sundar Rajan' },
  { id: 'att-08', studentId: 'stu-01', studentName: 'Sabarmathi T', studentRollNo: '21CS104', department: 'Computer Science & Engineering', subjectId: 'subj-cs802', subject: 'Advanced Database Systems (CS802)', date: '2026-09-30', status: 'absent', facultyId: 'fac-01', facultyName: 'Dr. Sundar Rajan', remarks: 'Unexcused absence during indexing lab' },
  { id: 'att-09', studentId: 'stu-01', studentName: 'Sabarmathi T', studentRollNo: '21CS104', department: 'Computer Science & Engineering', subjectId: 'subj-cs802', subject: 'Advanced Database Systems (CS802)', date: '2026-10-01', status: 'present', facultyId: 'fac-01', facultyName: 'Dr. Sundar Rajan' },

  // Subject 3: Cloud Computing (CS803) - Sabarmathi
  { id: 'att-10', studentId: 'stu-01', studentName: 'Sabarmathi T', studentRollNo: '21CS104', department: 'Computer Science & Engineering', subjectId: 'subj-cs803', subject: 'Cloud Computing & DevOps (CS803)', date: '2026-09-24', status: 'present', facultyId: 'fac-02', facultyName: 'Prof. Meenakshi Sundaram' },
  { id: 'att-11', studentId: 'stu-01', studentName: 'Sabarmathi T', studentRollNo: '21CS104', department: 'Computer Science & Engineering', subjectId: 'subj-cs803', subject: 'Cloud Computing & DevOps (CS803)', date: '2026-09-27', status: 'present', facultyId: 'fac-02', facultyName: 'Prof. Meenakshi Sundaram' },
  { id: 'att-12', studentId: 'stu-01', studentName: 'Sabarmathi T', studentRollNo: '21CS104', department: 'Computer Science & Engineering', subjectId: 'subj-cs803', subject: 'Cloud Computing & DevOps (CS803)', date: '2026-09-29', status: 'present', facultyId: 'fac-02', facultyName: 'Prof. Meenakshi Sundaram' },

  // Rahul Verma (stu-02)
  { id: 'att-13', studentId: 'stu-02', studentName: 'Rahul Verma', studentRollNo: '21CS118', department: 'Computer Science & Engineering', subjectId: 'subj-cs801', subject: 'Distributed Systems (CS801)', date: '2026-09-25', status: 'absent', facultyId: 'fac-01', facultyName: 'Dr. Sundar Rajan' },
  { id: 'att-14', studentId: 'stu-02', studentName: 'Rahul Verma', studentRollNo: '21CS118', department: 'Computer Science & Engineering', subjectId: 'subj-cs801', subject: 'Distributed Systems (CS801)', date: '2026-09-26', status: 'absent', facultyId: 'fac-01', facultyName: 'Dr. Sundar Rajan' },
  { id: 'att-15', studentId: 'stu-02', studentName: 'Rahul Verma', studentRollNo: '21CS118', department: 'Computer Science & Engineering', subjectId: 'subj-cs801', subject: 'Distributed Systems (CS801)', date: '2026-09-28', status: 'present', facultyId: 'fac-01', facultyName: 'Dr. Sundar Rajan' },
  { id: 'att-16', studentId: 'stu-02', studentName: 'Rahul Verma', studentRollNo: '21CS118', department: 'Computer Science & Engineering', subjectId: 'subj-cs801', subject: 'Distributed Systems (CS801)', date: '2026-09-29', status: 'present', facultyId: 'fac-01', facultyName: 'Dr. Sundar Rajan' },
  { id: 'att-17', studentId: 'stu-02', studentName: 'Rahul Verma', studentRollNo: '21CS118', department: 'Computer Science & Engineering', subjectId: 'subj-cs801', subject: 'Distributed Systems (CS801)', date: '2026-10-01', status: 'absent', facultyId: 'fac-01', facultyName: 'Dr. Sundar Rajan' },

  // Sneha Patel (stu-05) - Low Attendance
  { id: 'att-18', studentId: 'stu-05', studentName: 'Sneha Patel', studentRollNo: '21CS134', department: 'Computer Science & Engineering', subjectId: 'subj-cs801', subject: 'Distributed Systems (CS801)', date: '2026-09-25', status: 'absent', facultyId: 'fac-01', facultyName: 'Dr. Sundar Rajan' },
  { id: 'att-19', studentId: 'stu-05', studentName: 'Sneha Patel', studentRollNo: '21CS134', department: 'Computer Science & Engineering', subjectId: 'subj-cs801', subject: 'Distributed Systems (CS801)', date: '2026-09-26', status: 'absent', facultyId: 'fac-01', facultyName: 'Dr. Sundar Rajan' },
  { id: 'att-20', studentId: 'stu-05', studentName: 'Sneha Patel', studentRollNo: '21CS134', department: 'Computer Science & Engineering', subjectId: 'subj-cs801', subject: 'Distributed Systems (CS801)', date: '2026-09-28', status: 'absent', facultyId: 'fac-01', facultyName: 'Dr. Sundar Rajan' }
];

export const INITIAL_INTERNAL_MARKS: InternalMarkRecord[] = [
  {
    id: 'im-01',
    studentId: 'stu-01',
    studentName: 'Sabarmathi T',
    studentRollNo: '21CS104',
    subjectId: 'subj-cs801',
    subjectName: 'Distributed Systems (CS801)',
    testName: 'Internal Assessment 1 (IA-1)',
    maxMarks: 50,
    marksObtained: 47,
    date: '2026-09-12',
    facultyId: 'fac-01',
    facultyName: 'Dr. Sundar Rajan'
  },
  {
    id: 'im-02',
    studentId: 'stu-01',
    studentName: 'Sabarmathi T',
    studentRollNo: '21CS104',
    subjectId: 'subj-cs801',
    subjectName: 'Distributed Systems (CS801)',
    testName: 'Internal Assessment 2 (IA-2)',
    maxMarks: 50,
    marksObtained: 46,
    date: '2026-09-28',
    facultyId: 'fac-01',
    facultyName: 'Dr. Sundar Rajan'
  },
  {
    id: 'im-03',
    studentId: 'stu-01',
    studentName: 'Sabarmathi T',
    studentRollNo: '21CS104',
    subjectId: 'subj-cs802',
    subjectName: 'Advanced Database Systems (CS802)',
    testName: 'Internal Assessment 1 (IA-1)',
    maxMarks: 50,
    marksObtained: 44,
    date: '2026-09-14',
    facultyId: 'fac-01',
    facultyName: 'Dr. Sundar Rajan'
  },
  {
    id: 'im-04',
    studentId: 'stu-01',
    studentName: 'Sabarmathi T',
    studentRollNo: '21CS104',
    subjectId: 'subj-cs803',
    subjectName: 'Cloud Computing & DevOps (CS803)',
    testName: 'Internal Assessment 1 (IA-1)',
    maxMarks: 50,
    marksObtained: 48,
    date: '2026-09-16',
    facultyId: 'fac-02',
    facultyName: 'Prof. Meenakshi Sundaram'
  },
  {
    id: 'im-05',
    studentId: 'stu-02',
    studentName: 'Rahul Verma',
    studentRollNo: '21CS118',
    subjectId: 'subj-cs801',
    subjectName: 'Distributed Systems (CS801)',
    testName: 'Internal Assessment 1 (IA-1)',
    maxMarks: 50,
    marksObtained: 38,
    date: '2026-09-12',
    facultyId: 'fac-01',
    facultyName: 'Dr. Sundar Rajan'
  }
];

export const INITIAL_SEMESTER_MARKS: SemesterMarkRecord[] = [
  {
    id: 'sm-01',
    studentId: 'stu-01',
    studentName: 'Sabarmathi T',
    studentRollNo: '21CS104',
    subjectId: 'subj-cs701',
    subjectName: 'Compiler Design & Automata',
    semester: 'Semester VII',
    maxMarks: 100,
    marksObtained: 92,
    grade: 'O (Outstanding)',
    resultStatus: 'Pass'
  },
  {
    id: 'sm-02',
    studentId: 'stu-01',
    studentName: 'Sabarmathi T',
    studentRollNo: '21CS104',
    subjectId: 'subj-cs702',
    subjectName: 'Cryptographic Network Security',
    semester: 'Semester VII',
    maxMarks: 100,
    marksObtained: 88,
    grade: 'A+ (Excellent)',
    resultStatus: 'Pass'
  },
  {
    id: 'sm-03',
    studentId: 'stu-01',
    studentName: 'Sabarmathi T',
    studentRollNo: '21CS104',
    subjectId: 'subj-cs703',
    subjectName: 'Full-Stack Modern Web Engineering',
    semester: 'Semester VII',
    maxMarks: 100,
    marksObtained: 95,
    grade: 'O (Outstanding)',
    resultStatus: 'Pass'
  },
  {
    id: 'sm-04',
    studentId: 'stu-02',
    studentName: 'Rahul Verma',
    studentRollNo: '21CS118',
    subjectId: 'subj-cs701',
    subjectName: 'Compiler Design & Automata',
    semester: 'Semester VII',
    maxMarks: 100,
    marksObtained: 74,
    grade: 'B+ (Good)',
    resultStatus: 'Pass'
  }
];

export const INITIAL_JOB_POSTS: JobPost[] = [
  {
    id: 'job-01',
    title: 'Associate Software Development Engineer (Full-Stack)',
    company: 'NexaTech Systems',
    recruiterId: 'rec-01',
    description: 'We are seeking high-caliber final-year engineers to join our Core Platform Engineering team. You will architect high-throughput microservices, interactive React/TypeScript user interfaces, and cloud-native Kubernetes workloads.',
    requiredSkills: ['React', 'TypeScript', 'Node.js', 'FastAPI', 'PostgreSQL', 'Docker'],
    minCGPA: 8.0,
    eligibleDepartments: ['Computer Science & Engineering', 'Information Technology', 'CSE', 'IT'],
    graduationYear: 2026,
    applicationDeadline: '2026-10-25',
    jobType: 'Full-Time',
    location: 'Bengaluru / Hybrid',
    salaryPackage: '₹14.5 - ₹18.0 LPA',
    createdAt: '2026-09-25',
    isActive: true
  },
  {
    id: 'job-02',
    title: 'Cloud Infrastructure & DevOps Engineer',
    company: 'CloudScale Global',
    recruiterId: 'rec-02',
    description: 'Join our Enterprise Cloud Reliability organization building automated multi-region deployment fabrics, Terraform orchestration pipelines, and scalable observability stacks.',
    requiredSkills: ['Docker', 'Kubernetes', 'Python', 'Linux', 'AWS Basics', 'CI/CD'],
    minCGPA: 7.5,
    eligibleDepartments: ['Computer Science & Engineering', 'Information Technology', 'Electronics & Communication', 'CSE', 'IT', 'ECE'],
    graduationYear: 2026,
    applicationDeadline: '2026-10-28',
    jobType: 'Placement Drive',
    location: 'Hyderabad / On-Campus',
    salaryPackage: '₹16.0 - ₹21.0 LPA',
    createdAt: '2026-09-28',
    isActive: true
  },
  {
    id: 'job-03',
    title: 'AI/ML Research Intern (Autonomous Agents)',
    company: 'NexaTech Systems',
    recruiterId: 'rec-01',
    description: '6-month pre-placement internship focused on developing multi-agent LLM reasoning workflows, vector index optimization, and evaluation pipelines.',
    requiredSkills: ['Python', 'FastAPI', 'Machine Learning', 'TensorFlow', 'PostgreSQL'],
    minCGPA: 8.5,
    eligibleDepartments: ['Computer Science & Engineering', 'Information Technology', 'CSE', 'IT'],
    graduationYear: 2026,
    applicationDeadline: '2026-10-31',
    jobType: 'Internship',
    location: 'Remote / Bengaluru',
    salaryPackage: '₹55,000 / month (Stipend)',
    createdAt: '2026-10-01',
    isActive: true
  },
  {
    id: 'job-04',
    title: 'Backend Systems Developer (Java/Go)',
    company: 'FinTrack Global Technologies',
    recruiterId: 'rec-02',
    description: 'Design and implement low-latency transaction processing pipelines for financial institutions with strict data consistency guarantees.',
    requiredSkills: ['Java', 'Spring Boot', 'MySQL', 'Docker', 'Git'],
    minCGPA: 7.0,
    eligibleDepartments: ['Computer Science & Engineering', 'Information Technology', 'CSE', 'IT'],
    graduationYear: 2026,
    applicationDeadline: '2026-11-05',
    jobType: 'Full-Time',
    location: 'Chennai / On-Site',
    salaryPackage: '₹10.0 - ₹12.5 LPA',
    createdAt: '2026-09-29',
    isActive: true
  }
];

export const INITIAL_APPLICATIONS: Application[] = [
  {
    id: 'app-01',
    jobId: 'job-01',
    jobTitle: 'Associate Software Development Engineer (Full-Stack)',
    company: 'NexaTech Systems',
    studentId: 'stu-01',
    studentName: 'Sabarmathi T',
    studentRollNo: '21CS104',
    studentDepartment: 'Computer Science & Engineering',
    studentCGPA: 8.92,
    studentSkills: ['React', 'TypeScript', 'Node.js', 'Python', 'FastAPI', 'Docker', 'PostgreSQL', 'Machine Learning'],
    appliedDate: '2026-09-26',
    status: 'Interviewing',
    currentRoundName: 'Round 2: Technical Interview (System Design & React)',
    coverLetter: 'I have hands-on experience building distributed full-stack systems with React 19, TypeScript, and FastAPI, matching your platform core engineering specifications.',
    interviewRounds: [
      {
        id: 'rnd-01',
        applicationId: 'app-01',
        roundNumber: 1,
        roundName: 'Round 1: Online Technical Assessment',
        dateTime: '2026-09-30T10:00:00Z',
        mode: 'Hackerrank Platform',
        status: 'Selected',
        meetingLinkOrVenue: 'https://assess.hackerrank.com/test/nxt-campus-2026',
        interviewer: 'Automated Proctoring Bot',
        feedback: 'Score: 100/100. Completed DSA problems on Graph traversal and dynamic programming with optimal time complexity.',
        scheduledBy: 'rec-01',
        updatedAt: '2026-10-01T09:00:00Z'
      },
      {
        id: 'rnd-02',
        applicationId: 'app-01',
        roundNumber: 2,
        roundName: 'Round 2: Technical Interview (System Design & React)',
        dateTime: '2026-10-05T14:30:00Z',
        mode: 'Online (Google Meet)',
        status: 'Scheduled',
        meetingLinkOrVenue: 'https://meet.google.com/nxt-tech-interview',
        interviewer: 'Priya Menon & Lead Architect',
        feedback: 'Candidate scheduled for deep dive into state management, concurrency, and RESTful API contracts.',
        scheduledBy: 'rec-01',
        updatedAt: '2026-10-01T15:00:00Z'
      }
    ]
  },
  {
    id: 'app-02',
    jobId: 'job-02',
    jobTitle: 'Cloud Infrastructure & DevOps Engineer',
    company: 'CloudScale Global',
    studentId: 'stu-01',
    studentName: 'Sabarmathi T',
    studentRollNo: '21CS104',
    studentDepartment: 'Computer Science & Engineering',
    studentCGPA: 8.92,
    studentSkills: ['React', 'TypeScript', 'Node.js', 'Python', 'FastAPI', 'Docker', 'PostgreSQL', 'Machine Learning'],
    appliedDate: '2026-09-29',
    status: 'Shortlisted',
    currentRoundName: 'Round 1: Linux & Containerization Screener',
    coverLetter: 'Passionate about containerized orchestration, infrastructure as code, and CI/CD pipelines.',
    interviewRounds: [
      {
        id: 'rnd-03',
        applicationId: 'app-02',
        roundNumber: 1,
        roundName: 'Round 1: Linux & Containerization Screener',
        dateTime: '2026-10-08T11:00:00Z',
        mode: 'Virtual Interview',
        status: 'Scheduled',
        meetingLinkOrVenue: 'https://cloudscale.chime.aws/interview-8812',
        interviewer: 'David Chen',
        scheduledBy: 'rec-02',
        updatedAt: '2026-09-30T16:00:00Z'
      }
    ]
  },
  {
    id: 'app-03',
    jobId: 'job-04',
    jobTitle: 'Backend Systems Developer (Java/Go)',
    company: 'FinTrack Global Technologies',
    studentId: 'stu-02',
    studentName: 'Rahul Verma',
    studentRollNo: '21CS118',
    studentDepartment: 'Computer Science & Engineering',
    studentCGPA: 7.45,
    studentSkills: ['Java', 'Spring Boot', 'MySQL', 'Git', 'HTML', 'CSS', 'AWS Basics'],
    appliedDate: '2026-09-30',
    status: 'Shortlisted',
    currentRoundName: 'Round 1: Java Core & SQL Coding Round',
    coverLetter: 'Strong fundamentals in Java Spring Boot and relational database design.',
    interviewRounds: [
      {
        id: 'rnd-04',
        applicationId: 'app-03',
        roundNumber: 1,
        roundName: 'Round 1: Java Core & SQL Coding Round',
        dateTime: '2026-10-06T15:00:00Z',
        mode: 'Online (Google Meet)',
        status: 'Scheduled',
        meetingLinkOrVenue: 'https://meet.google.com/ftg-code-screener',
        interviewer: 'Senior FinTech Lead',
        scheduledBy: 'tpo-01',
        updatedAt: '2026-10-01T12:00:00Z'
      }
    ]
  },
  {
    id: 'app-04',
    jobId: 'job-03',
    jobTitle: 'AI/ML Research Intern (Autonomous Agents)',
    company: 'NexaTech Systems',
    studentId: 'stu-03',
    studentName: 'Ananya Iyer',
    studentRollNo: '21IT045',
    studentDepartment: 'Information Technology',
    studentCGPA: 9.15,
    studentSkills: ['Python', 'TensorFlow', 'PyTorch', 'SQL', 'FastAPI', 'Data Analytics', 'Computer Vision'],
    appliedDate: '2026-10-01',
    status: 'Applied',
    currentRoundName: 'Application Received',
    interviewRounds: []
  },
  {
    id: 'app-05',
    jobId: 'job-03',
    jobTitle: 'AI/ML Research Intern (Autonomous Agents)',
    company: 'NexaTech Systems',
    studentId: 'stu-01',
    studentName: 'Sabarmathi T',
    studentRollNo: '21CS104',
    studentDepartment: 'Computer Science & Engineering',
    studentCGPA: 8.92,
    studentSkills: ['React', 'TypeScript', 'Node.js', 'Python', 'FastAPI', 'Docker', 'PostgreSQL', 'Machine Learning'],
    appliedDate: '2026-10-02',
    status: 'Applied',
    currentRoundName: 'Application Received',
    coverLetter: 'Strong interest in LLM orchestration, multi-agent frameworks, and vector index performance optimization.',
    interviewRounds: []
  },
  {
    id: 'app-06',
    jobId: 'job-04',
    jobTitle: 'Backend Systems Developer (Java/Go)',
    company: 'FinTrack Global Technologies',
    studentId: 'stu-01',
    studentName: 'Sabarmathi T',
    studentRollNo: '21CS104',
    studentDepartment: 'Computer Science & Engineering',
    studentCGPA: 8.92,
    studentSkills: ['React', 'TypeScript', 'Node.js', 'Python', 'FastAPI', 'Docker', 'PostgreSQL', 'Machine Learning'],
    appliedDate: '2026-09-20',
    status: 'Rejected',
    currentRoundName: 'Round 2: Technical Interview (Core Systems & DSA)',
    finalResult: 'Rejected',
    coverLetter: 'Passionate about high-throughput distributed transaction processing.',
    rejectionFeedback: {
      id: 'rf-06',
      applicationId: 'app-06',
      interviewRoundId: 'rnd-06b',
      roundName: 'Round 2: Technical Interview (Core Systems & DSA)',
      recruiterId: 'rec-02',
      recruiterName: 'David Chen',
      companyName: 'FinTrack Global Technologies',
      category: 'Coding/technical assessment performance',
      feedback: 'Performance in live algorithmic coding and concurrent state synchronization fell below senior engineering thresholds. Candidate needs greater depth in explaining architectural trade-offs.',
      rejectedAt: '2026-09-27T17:00:00Z'
    },
    interviewRounds: [
      {
        id: 'rnd-06a',
        applicationId: 'app-06',
        roundNumber: 1,
        roundName: 'Round 1: Online Technical Assessment',
        dateTime: '2026-09-23T11:00:00Z',
        mode: 'Hackerrank Platform',
        status: 'Selected',
        meetingLinkOrVenue: 'https://assess.hackerrank.com/test/ftg-screener',
        interviewer: 'Automated Proctoring Bot',
        feedback: 'Score: 92/100. Completed algorithmic challenges within time limit.',
        scheduledBy: 'rec-02',
        updatedAt: '2026-09-23T12:00:00Z'
      },
      {
        id: 'rnd-06b',
        applicationId: 'app-06',
        roundNumber: 2,
        roundName: 'Round 2: Technical Interview (Core Systems & DSA)',
        dateTime: '2026-09-27T15:30:00Z',
        mode: 'Online (Google Meet)',
        status: 'Rejected',
        meetingLinkOrVenue: 'https://meet.google.com/ftg-tech-round2',
        interviewer: 'Raghavan S. (Lead Systems Architect)',
        feedback: 'Needs improvement in data structures, problem-solving approach, and explaining project architecture.',
        rejectionReason: 'Performance in live algorithmic coding and concurrent state synchronization fell below senior engineering thresholds.',
        rejectionFeedback: {
          id: 'rf-06',
          applicationId: 'app-06',
          interviewRoundId: 'rnd-06b',
          roundName: 'Round 2: Technical Interview (Core Systems & DSA)',
          recruiterId: 'rec-02',
          recruiterName: 'David Chen',
          companyName: 'FinTrack Global Technologies',
          category: 'Coding/technical assessment performance',
          feedback: 'Performance in live algorithmic coding and concurrent state synchronization fell below senior engineering thresholds. Candidate needs greater depth in explaining architectural trade-offs.',
          rejectedAt: '2026-09-27T17:00:00Z'
        },
        areasForImprovement: [
          'Practice data structures and algorithms (focus on trees, graphs, and dynamic programming).',
          'Review project implementation and explain architectural trade-offs with greater depth.',
          'Improve technical communication and articulation of complexity trade-offs during live coding.'
        ],
        scheduledBy: 'rec-02',
        updatedAt: '2026-09-27T17:00:00Z'
      }
    ]
  },
  {
    id: 'app-07',
    jobId: 'job-02',
    jobTitle: 'Cloud Infrastructure & DevOps Engineer',
    company: 'CloudScale Global',
    studentId: 'stu-02',
    studentName: 'Rahul Verma',
    studentRollNo: '21CS118',
    studentDepartment: 'Computer Science & Engineering',
    studentCGPA: 7.45,
    studentSkills: ['Java', 'Spring Boot', 'MySQL', 'Git'],
    appliedDate: '2026-09-18',
    status: 'Rejected',
    currentRoundName: 'Round 1: Initial Resume Screener',
    finalResult: 'Rejected',
    interviewRounds: [
      {
        id: 'rnd-07a',
        applicationId: 'app-07',
        roundNumber: 1,
        roundName: 'Round 1: Initial Resume Screener',
        dateTime: '2026-09-22T10:00:00Z',
        mode: 'Virtual Interview',
        status: 'Rejected',
        scheduledBy: 'rec-02',
        updatedAt: '2026-09-22T11:00:00Z'
        // Notice: feedback is deliberately undefined to test "No detailed feedback has been provided yet."
      }
    ]
  }
];

export const INITIAL_PLACEMENT_DRIVES: PlacementDrive[] = [
  {
    id: 'drv-01',
    jobId: 'job-01',
    company: 'NexaTech Systems',
    role: 'Associate Software Development Engineer (Full-Stack)',
    driveDate: '2026-10-25',
    minCGPA: 8.0,
    eligibleDepartments: ['Computer Science & Engineering', 'Information Technology'],
    graduationYear: 2026,
    salaryPackage: '₹14.5 - ₹18.0 LPA',
    status: 'Active',
    location: 'Campus Tech Auditorium & Virtual',
    notes: 'Round 1 HackerRank online assessment completed. Round 2 interviews underway.'
  },
  {
    id: 'drv-02',
    jobId: 'job-02',
    company: 'CloudScale Global',
    role: 'Cloud Infrastructure & DevOps Engineer',
    driveDate: '2026-10-28',
    minCGPA: 7.5,
    eligibleDepartments: ['Computer Science & Engineering', 'Information Technology', 'Electronics & Communication'],
    graduationYear: 2026,
    salaryPackage: '₹16.0 - ₹21.0 LPA',
    status: 'Upcoming',
    location: 'Placement Block Seminar Hall A',
    notes: 'Pre-placement presentation at 09:30 AM followed by offline aptitude test.'
  },
  {
    id: 'drv-03',
    jobId: 'job-04',
    company: 'FinTrack Global Technologies',
    role: 'Backend Systems Developer (Java/Go)',
    driveDate: '2026-11-05',
    minCGPA: 7.0,
    eligibleDepartments: ['Computer Science & Engineering', 'Information Technology'],
    graduationYear: 2026,
    salaryPackage: '₹10.0 - ₹12.5 LPA',
    status: 'Upcoming',
    location: 'Virtual Recruitment Platform',
    notes: 'Shortlisting applications from 2026 graduating batch.'
  }
];

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'proj-01',
    title: 'Multi-Agent AI Campus Productivity, Academic, and Placement System',
    description: 'An integrated multi-agent campus operations platform synchronizing student academic tracking, real-time faculty attendance, automated recruitment matching, and interview round lifecycles.',
    leadStudentId: 'stu-01',
    leadStudentName: 'Sabarmathi T',
    teamMembers: ['Sabarmathi T (Lead)', 'Rahul Verma', 'Ananya Iyer'],
    guideFacultyName: 'Dr. Sundar Rajan',
    guideFacultyId: 'fac-01',
    department: 'Computer Science & Engineering',
    category: 'Capstone',
    status: 'In Progress',
    progressPercentage: 85,
    milestones: [
      { id: 'm-01', title: 'System Architecture & Schema Design', dueDate: '2026-08-30', completed: true },
      { id: 'm-02', title: 'Role-Based Authentication & Portal UI', dueDate: '2026-09-15', completed: true },
      { id: 'm-03', title: 'Integrated Academic & Placement Synchronization', dueDate: '2026-10-05', completed: true },
      { id: 'm-04', title: 'Multi-Agent AI Advisor & Live Evaluation', dueDate: '2026-10-20', completed: false },
      { id: 'm-05', title: 'Final Capstone Project Defense', dueDate: '2026-11-10', completed: false }
    ],
    githubUrl: 'https://github.com/campus-capstone/multi-agent-campus-hub'
  },
  {
    id: 'proj-02',
    title: 'IoT Smart Campus Energy Monitoring & Grid Automation',
    description: 'LoRaWAN sensor telemetry network monitoring classroom HVAC and lighting loads with predictive anomaly detection.',
    leadStudentId: 'stu-04',
    leadStudentName: 'Karthik Raman',
    teamMembers: ['Karthik Raman', 'Sneha Patel'],
    guideFacultyName: 'Prof. Meenakshi Sundaram',
    guideFacultyId: 'fac-02',
    department: 'Electronics & Communication',
    category: 'Research',
    status: 'In Progress',
    progressPercentage: 60,
    milestones: [
      { id: 'm-11', title: 'Sensor Hardware Prototyping', dueDate: '2026-09-10', completed: true },
      { id: 'm-12', title: 'Gateway Telemetry Pipeline', dueDate: '2026-10-12', completed: false },
      { id: 'm-13', title: 'Energy Savings Analytical Dashboard', dueDate: '2026-11-01', completed: false }
    ]
  }
];

export const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'notif-01',
    targetUserId: 'stu-01',
    title: 'Interview Round 1 Result',
    message: 'Congratulations! You have been Selected in Round 1: Online Technical Assessment for NexaTech Systems.',
    type: 'interview',
    read: false,
    createdAt: '2026-10-01T09:05:00Z',
    link: '/interview-progress'
  },
  {
    id: 'notif-02',
    targetUserId: 'stu-01',
    title: 'Interview Round 2 Scheduled',
    message: 'NexaTech Systems scheduled your Technical Interview for Oct 05, 2026 at 02:30 PM.',
    type: 'interview',
    read: false,
    createdAt: '2026-10-01T15:02:00Z',
    link: '/interview-progress'
  },
  {
    id: 'notif-03',
    targetUserId: 'stu-01',
    title: 'New Assignment Published',
    message: 'Dr. Sundar Rajan created a new assignment: PostgreSQL Query Optimization & Index Benchmarking.',
    type: 'assignment',
    read: true,
    createdAt: '2026-10-01T10:00:00Z',
    link: '/assignments'
  },
  {
    id: 'notif-04',
    targetUserId: 'fac-01',
    title: 'Assignment Submitted',
    message: 'Sabarmathi T submitted "Distributed Consensus & Raft Protocol Simulation".',
    type: 'assignment',
    read: false,
    createdAt: '2026-10-01T14:31:00Z',
    link: '/assignments'
  },
  {
    id: 'notif-05',
    targetUserId: 'tpo-01',
    title: 'New Recruiter Job Posting',
    message: 'NexaTech Systems posted: Associate Software Development Engineer (Full-Stack) with 3 eligible candidates.',
    type: 'job',
    read: false,
    createdAt: '2026-09-25T11:00:00Z',
    link: '/opportunities'
  },
  {
    id: 'notif-06',
    targetUserId: 'rec-01',
    title: 'New Applicant Received',
    message: 'Sabarmathi T (CGPA 8.92, 100% Skill Match) applied for Associate SDE role.',
    type: 'job',
    read: true,
    createdAt: '2026-09-26T12:00:00Z',
    link: '/applicants'
  }
];

export const INITIAL_CALENDAR_EVENTS: CalendarEvent[] = [
  {
    id: 'ev-01',
    title: 'Raft Consensus Assignment Deadline',
    category: 'assignment',
    date: '2026-10-18',
    time: '23:59',
    description: 'Distributed Systems CS801 lab report submission due.',
    targetRole: 'all'
  },
  {
    id: 'ev-02',
    title: 'NexaTech SDE Technical Interview (Sabarmathi T)',
    category: 'interview',
    date: '2026-10-05',
    time: '14:30',
    description: 'System design and React frontend deep dive via Google Meet.',
    targetRole: 'all'
  },
  {
    id: 'ev-03',
    title: 'CloudScale Global On-Campus Placement Drive',
    category: 'placement',
    date: '2026-10-12',
    time: '09:00',
    description: 'Pre-placement talk followed by aptitude screening in Auditorium A.',
    targetRole: 'all'
  },
  {
    id: 'ev-04',
    title: 'Mid-Semester Examinations: Distributed Systems',
    category: 'exam',
    date: '2026-10-22',
    time: '10:00',
    description: 'Hall 302, Academic Block 2.',
    targetRole: 'all'
  },
  {
    id: 'ev-05',
    title: 'Capstone Project Phase-3 Milestone Evaluation',
    category: 'project',
    date: '2026-10-20',
    time: '14:00',
    description: 'Review with faculty committee and external industry mentors.',
    targetRole: 'all'
  }
];

export const AI_AGENTS: AIAgent[] = [
  {
    id: 'agent-student',
    name: 'Student Career & Academic Advisor',
    role: 'Student Advisor Agent',
    specialty: 'Attendance compliance, assignment deadlines, academic marks, resume skill gap analysis, job eligibility, and interview progress.',
    avatarColor: 'blue',
    welcomeMessage: 'Hello! I am your Campus Student Advisor Agent. I have full context of your attendance records, coursework marks, uploaded resume, and active job applications.',
    suggestedPrompts: [
      'What is my current attendance percentage?',
      'Which assignments are pending?',
      'What skills should I learn for a backend developer role?',
      'Which jobs am I eligible for?',
      'What is my interview status?'
    ]
  },
  {
    id: 'agent-faculty',
    name: 'Faculty Academic Proctor & Course Guide',
    role: 'Faculty Operations Agent',
    specialty: 'Student attendance audits, assignment submission summaries, grading status, low attendance flags, and performance benchmarks.',
    avatarColor: 'emerald',
    welcomeMessage: 'Welcome, Professor. I track all course attendance logs, submission deadlines, and student performance across your assigned subjects.',
    suggestedPrompts: [
      'Which students have low attendance?',
      'How many students have submitted the assignment?',
      'Which students have pending submissions?',
      'Summarize class performance in Distributed Systems'
    ]
  },
  {
    id: 'agent-recruiter',
    name: 'University Talent Acquisition Screener',
    role: 'Recruiter Agent',
    specialty: 'Job post candidate matching, candidate skill matches, applicant pipeline verification, and scheduled interview rounds.',
    avatarColor: 'amber',
    welcomeMessage: 'Welcome! I am your University Talent Screener Agent. I can evaluate registered student batches against your hiring criteria and track applicant progression.',
    suggestedPrompts: [
      'Show eligible candidates for my job',
      'How many applicants have applied?',
      'Which candidates are awaiting interviews?',
      'What is the skill match breakdown for applicants?'
    ]
  },
  {
    id: 'agent-placement',
    name: 'Placement Directorate Coordinator',
    role: 'Placement Cell Agent',
    specialty: 'Placement drives, class-wide eligibility, applications, non-applicant identification, interview rounds, and offer statistics.',
    avatarColor: 'purple',
    welcomeMessage: 'Greetings! I am the Central Placement Cell Intelligence Agent, tracking campus drives, student eligibility rosters, and recruitment offers.',
    suggestedPrompts: [
      'How many students are eligible for the current drive?',
      'Who has not applied yet?',
      'How many students were selected?',
      'Which students are awaiting interview results?'
    ]
  }
];
