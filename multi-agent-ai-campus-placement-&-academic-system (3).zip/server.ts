import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { aiRouter } from './src/server/routes/aiRoutes';
import { dashboardRouter } from './src/server/routes/dashboardRoutes';
import { academicRouter } from './src/server/routes/academicRoutes';
import { placementRouter } from './src/server/routes/placementRoutes';
import { realtimeRouter } from './src/server/routes/realtimeRoutes';
import { authRouter } from './src/server/routes/authRoutes';

const PORT = 3000;

async function startServer() {
  const app = express();

  // Middleware
  app.use(express.json({ limit: '10mb' }));

  // API Routes
  app.use('/api/ai', aiRouter);
  app.use('/api/dashboard', dashboardRouter);
  app.use('/api/academic', academicRouter);
  app.use('/api/placement', placementRouter);
  app.use('/api/realtime', realtimeRouter);
  app.use('/api/auth', authRouter);

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      service: 'Campus Multi-Agent AI Management System'
    });
  });

  // Vite middleware in dev or static files in production
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true, host: '0.0.0.0', port: PORT },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Multi-Agent Campus Backend Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Fatal error starting server:', err);
  process.exit(1);
});
